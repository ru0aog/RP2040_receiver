﻿/**  
 * ============================================================================  
 *  vfo_hardware.cpp — Дизеринг-движок программного DDS VFO на автоматах PIO  
 *  Версия 2.26 от 2026-10-20, автор RU0AOG  
 * ============================================================================ 
 *  
 *  МНОГОКРИТЕРИАЛЬНЫЙ АВТОТЮН PLL И ДВУХЪЯДЕРНЫЙ ДИЗЕРИНГ
 *  Профилирование и ASM-оптимизация Core 1
 *  
 *  Этот файл — часть RP2040_beacon, распространяется под GPLv3  
 *  (см. LICENSE в корне репозитория).
 * ============================================================================  
 */

#include "hardware/pio.h"
#include "hardware/clocks.h"
#include "hardware/pll.h"
#include "hardware/sync.h"
#include "hardware/resets.h"
#include "hardware/timer.h"
#include "hardware/vreg.h"
#include <hardware/watchdog.h>
#include <hardware/adc.h>
#include "hardware/divider.h"
#include "hardware/structs/sio.h"
#include "hardware/structs/ssi.h"
#include "hardware/structs/pll.h"
#include "pico/multicore.h"
#include "pico/stdlib.h"
#include "vfo_hardware.h"

// данные из параллельного проекта
// ============================================================================
int pin_freq_out = 0;
// GPIO управления ДПФ (значения подставить из конфигурации)
static const int subband_pins[] = {
    2, 3, 4, -1
};
// ============================================================================



// ДИАГНОСТИКА
#define BOOST_DEBUG              0         // 0 — выключить отладочную печать блока разгона
#define VFO_PLL_DEBUG            0         // 0 — выключить отладочную печать подбора кандидатов
#define PLL_RUNTIME_DEBUG        0         // 0 — выключить отладочную печать блока PLL

// ============================================================================
// МНОГОКРИТЕРИАЛЬНЫЙ АВТОТЮН PLL (ВЕРСИЯ С REFDIV И CTZ-ФИЛЬТРОМ)
// ============================================================================
#define VFO_INT_PENALTY        500000000ULL // жёсткий запрет pio_int < 4
#define VFO_SPUR_MIN_OFFSET_HZ 1000000ULL   // запретный пояс FRAC8-спура, Гц  
#define VFO_DMIN_CEILING       280000000ULL // гейт близкой гребёнки дизера (~6.5% от 2^32)
#define VFO_K8_BELT            (1u << 25)   // пояс отсечения у якорей k/8: 1u << 26 ±25% октавы
                            // (1u << 25)   // ~3 МГц офсет спура при clk~390M
                            // (1u << 26)   // ~6-7 МГц офсет спура при clk~390M
#define VFO_SHELF_REF_CLK_HZ   400000000ULL // опора нормировки подошвы: 400M = нулевой штраф  
#define VFO_SPUR_HORIZON_HZ    3000000ULL   // спур ближе 3 МГц — штраф за уровень
#define VFO_CLK_SYS_PREF_MIN_HZ  250000000ULL   // минимум clk_sys: ниже — сильная близкая гребёнка
#define VFO_PREFERRED_MIN_CLK    320000000ULL  // Нижняя граница зоны чистого спектра

// Структура детальной калькуляции штрафов
struct MetricBreakdown {  
    uint32_t raw_step;  
    uint32_t frac;  
    uint32_t ctz_val;  
    uint64_t ctz_penalty;  
    uint64_t center_dist;  
    uint64_t mash_penalty;  
    uint64_t clk_penalty;  
    uint64_t int_penalty;  
    uint64_t spur_power_pen;   // аналитическая цена уровня FRAC8-спура (∝ A/D² + prox³)  
    uint64_t total_metric;  
};

// ============================================================================
// ОБЪЯВЛЕНИЯ ФУНКЦИЙ И ПЕРЕМЕННЫХ
// ============================================================================
static void detach_peripheral_clock();
static void __not_in_flash_func(vfo_set_clk_sys)(const PllConfig& cfg, uint32_t vsel);
void __not_in_flash_func(vfo_dither_reset)(void);
static VfoParameters calculate_raw_params_mhz(uint64_t clk_sys_hz, uint64_t mhz_target);
PllConfig vfo_find_optimal_pll(unsigned int target_frequency_hz, uint64_t max_clk_limit);
// Упреждающий прототип для verbose-метрики (чтобы find_optimal_pll видела её выше по коду)
static uint64_t vfo_pll_metric_verbose(uint64_t clk_sys_hz, uint64_t target_mhz, MetricBreakdown *b, VfoParameters *out = nullptr);

// Добавлен упреждающий прототип Core 1, теперь vfo_clk_boost_enter сможет его вызвать!
static void __not_in_flash_func(vfo_core1_entry)();
static float frac_spur_level_db(uint16_t pio_int, uint8_t pio_frac);
// forward declaration  
static uint64_t frac_spur_min_off_hz(uint16_t pio_int, uint8_t pio_frac,  
                                     uint64_t clk_sys_hz);
static void vfo_rebuild_tone_table(uint64_t base_freq_mhz, uint64_t step_mhz); 
static vreg_voltage vsel_for(uint64_t clk_hz);
static uint16_t vsel_to_mv(uint32_t vsel);  
static uint64_t vfo_pll_metric(uint64_t clk_sys_hz, uint64_t target_mhz,  
                               VfoParameters* out = nullptr);

// Глобальные профили тактирования (static полностью удалены для extern-связывания)
// Обновляем глобальные профили тактирования (добавлен refdiv = 1 в конец каждого списка)
PllConfig pll_nominal   = { 133, 6, 2, 133000000ULL, (uint32_t)VREG_VOLTAGE_DEFAULT, false, 1 };
PllConfig pll_ceiling   = { 95,  3, 1, 380011083ULL, (uint32_t)VREG_VOLTAGE_1_30,    true,  1 };  
volatile bool clk_boosted = false;       // активация разгона
volatile bool vfo_auto_boost = false;    // авто-разгон, вычисляется один раз на старте

// Физическое размещение массива в RAM. Секция .time_critical гарантирует нахождение в ОЗУ
VfoParameters __attribute__((section(".time_critical.vfo_tones"))) vfo_tones[VFO_TONES_COUNT];

static inline __attribute__((always_inline)) uint32_t __not_in_flash_func(vfo_xorshift32_raw)(uint32_t state);
static inline __attribute__((always_inline)) uint32_t __not_in_flash_func(vfo_xorshift32)();

static PIO lo_pio = pio0;
static unsigned int lo_sm = 0;

static unsigned int lo_offset = 0;
static bool pio_program_loaded = false;

static uint8_t current_active_tone = VFO_TONE_NONE;
static volatile bool tone_changed = false;
static volatile bool dither_reset_pending = false;  // флаг сброса накопителей фазы MASH-дизера

// Межъядерный аппаратный спинлок
static spin_lock_t* vfo_spin_lock = nullptr;

// Переменные обмена данными между ядрами (Защищены спинлоком)
static volatile uint32_t dds_step = 0;          
static volatile uint32_t target_pio_int = 8;    
static volatile uint32_t target_pio_frac8 = 0;  
// Глубина FRAC-дизера как битовая маска ГПСЧ, выбирается по pio_int  
// при смене тона: 0x03 → ±3, 0x01 → ±1, 0x00 → выключен.  
static volatile uint32_t vfo_frac_dither_mask = 0x03u;
volatile uint8_t vfo_narrowband_mode = 0;   // 0 = обычный дизер, 1 = узкая полоса (Olivia)

// Глобальное состояние DDS-накопителей в ОЗУ (используется в С-ориентированных ветках)
static volatile uint32_t dds_accumulator = 0; 
static volatile uint32_t dds_accum_m2 = 0;    
static volatile uint32_t m2_carry_prev = 0;   

// Состояние встроенного ГПСЧ Xorshift32
#define VFO_RAND_SEED_INIT 0xACE1u
static volatile uint32_t xorshift_state = VFO_RAND_SEED_INIT;

static uint32_t current_clk_sys_hz = 120000000;

static double cached_step_hz = 100.0;
static uint32_t cached_base_freq_hz = 3500000;








// ============================================================================
// ГЕНЕРАТОР КВАДРАТУРНЫХ I/Q-СИГНАЛОВ ПРИЁМНИКА: 4-тактовая программа, 2 соседних пина
// ============================================================================

// --- Квадратура I/Q: один SM, 4-тактовая программа, 2 соседних пина ---  
// базовый пин PIO-блока = GP0 = Q, следующий = GP1 = I  
int pin_freq_out_i = 0;   // PIO base pin — физически это Q (GP0) - нарастает первый
int pin_freq_out_q = 1;   // base+1 — физически это I (GP1)       - второй

// Ассемблерная микропрограмма PIO для меандра (цикл из 4 тактов)
static const uint16_t pio_quad_instructions[] = {
    0xe001,  // set pins, 0b01: Q=1 I=0
    0xe003,  // set pins, 0b11: Q=1 I=1
    0xe002,  // set pins, 0b10: Q=0 I=1
    0xe000,  // set pins, 0b00: Q=0 I=0
};
static const pio_program_t pio_quad_program = {
    .instructions = pio_quad_instructions,
    .length = 4,
    .origin = -1,
    .pio_version = 0
};


static unsigned int quad_offset = 0;  
static bool quad_program_loaded = false;  
static bool quad_active = false;          // true = SM сконфигурирована под RX-квадратуру

void vfo_quadrature_start(uint32_t freq_hz);   // freq_hz = частота ПРИЁМА (LO ставится на freq−IF)  
void vfo_quadrature_stop(uint32_t freq_hz, double step_hz);  
uint32_t vfo_quadrature_lo_hz(void);           // фактическая частота LO после квантования clkdiv
static void __not_in_flash_func(vfo_set_clk_sys)(const PllConfig& cfg_in, uint32_t vsel);

// Фактическая квантованная частота LO (для NCO)  
static uint32_t quad_lo_actual_hz = 0;

uint32_t vfo_quadrature_lo_hz(void) {
    return quad_lo_actual_hz; 
}

// В маяке эти лимиты/коррекция живут в file_manager.cpp (из Flash).  
// У приёмника отдельного file_manager нет — определяем здесь с  
// паспортными значениями по умолчанию (как в комментариях vfo_hardware.h).  
uint32_t vfo_max_clk_sys_hz = 320000000UL;   // было VFO_CLK_SYS_NOMINAL_HZ (133 МГц)  
uint32_t vfo_max_pll_vco_hz = 2500000000UL;  // 2500 МГц достаточно: VCO/pdiv(min 4) = до 400 МГц  
int32_t  vfo_xosc_corr_ppb  = (int32_t)VFO_XOSC_DEFAULT_PPB;  // дефолт +25000 ppb

// Перевести VFO в RX-режим квадратурного LO (I/Q для SDR-смесителя).  
void vfo_quadrature_start(uint32_t freq_hz) {
    // Целевая частота LO — ниже настраиваемой на величину ПЧ  
    uint32_t lo_hz = (freq_hz > RX_IF_SHIFT_HZ) ? (freq_hz - RX_IF_SHIFT_HZ) : freq_hz;  
    Serial.print("[QUAD] Целевая частота "); Serial.println(lo_hz);

// === Подгонка clk_sys под ЦЕЛЫЙ делитель LO ===  
    // LO = clk_sys/(4*D), D — целый делитель PIO (дробный даёт джиттер -> спуры).  
    // На фиксированных 133 МГц целый D слишком «крупный» на ВЧ (на 14 МГц  
    // ближайший D=2 => 16.625 МГц, промах 2.5 МГц > ±62.5 кГц окна NCO).  
    // Ищем достижимую комбинацию PLL, при которой clk_sys/(4*D) ложится  
    // ближе всего к lo_hz, прошиваем её путём TX (vfo_set_clk_sys) и  
    // ПЕРЕСЧИТЫВАЕМ делитель от РЕАЛЬНОЙ шины.  
    const uint64_t xosc_hz = vfo_calibrated_xosc_hz();  
    const uint64_t clk_max = vfo_effective_clk_max();  
    const uint64_t vco_max = vfo_effective_pll_max();  
  
    // Веса лексикографики: W2 >> W3 >> W4 >> W5 (старший критерий доминирует).  
    const uint64_t W2 = 1000000000ull;  // П2: удаление от сладкой зоны (за 1 Гц)  
    const uint64_t W3 = 1000000ull;     // П3: штраф за дробный делитель  
    const uint64_t W4 = 1000ull;        // П4: близость дроби к k/8  
    const uint64_t W5 = 1ull;           // П5: шина ниже максимума (за 1 МГц)  
  
    PllConfig best        = pll_nominal;  // безопасный дефолт  
    uint64_t  best_cost   = UINT64_MAX;   // многокритериальная стоимость  
    uint32_t  best_div_q8 = 0;            // выбранный делитель Q8  
    bool      best_is_int = true;  
    bool      best_legal  = false;  
  
    // Fallback «наименьшее зло»: лучший среди НЕлегальных (дырка в 0..5 кГц).  
    PllConfig fb_best       = pll_nominal;  
    uint64_t  fb_bad        = UINT64_MAX; // чем меньше — тем ближе дырка к краю 5 кГц  
    uint32_t  fb_div_q8     = 0;  
    bool      fb_is_int     = true;  
  
    for (uint32_t refdiv = 1; refdiv <= 3; refdiv++) {  
        uint64_t ref_hz = xosc_hz / refdiv;  
        for (uint32_t p1 = 2; p1 <= 7; p1++) {  
            for (uint32_t p2 = 1; p2 <= 7; p2++) {  
                if (p1 < p2) continue;  
                uint32_t pdiv = p1 * p2;  
                for (uint32_t fbdiv = 16; fbdiv <= 320; fbdiv++) {  
                    uint64_t vco = ref_hz * fbdiv;  
                    if (vco < 750000000ULL || vco > vco_max) continue;  
                    uint64_t clk = vco / pdiv;  
                    if (clk < RX_CLK_SYS_MIN_HZ || clk > clk_max) continue;
  
                    // Два варианта делителя на эту шину: целый и дробный (Q8).  
                    for (int frac_mode = 0; frac_mode < 2; frac_mode++) {  
                        uint32_t div_q8;  
                        if (frac_mode == 0) {                 // целый  
                            uint64_t D = (clk + 2ull * lo_hz) / (4ull * lo_hz);  
                            if (D < 2)      D = 2;  
                            if (D > 0xFFFF) D = 0xFFFF;  
                            div_q8 = (uint32_t)(D << 8);  
                        } else {                              // дробный Q8  
                            uint64_t q = (clk * 256ull + 2ull * lo_hz) / (4ull * lo_hz);  
                            if (q < (2u << 8))      q = 2u << 8;  
                            if (q > (0xFFFFu << 8)) q = 0xFFFFu << 8;  
                            div_q8 = (uint32_t)q;  
                        }  
                        uint64_t lo_got = (clk * 256ull) / (4ull * (uint64_t)div_q8);  
                        if (lo_got >= freq_hz) continue;      // ПЧ положительна  
                        int64_t f_nco = (int64_t)freq_hz - (int64_t)lo_got;  
                        if (f_nco <= 0 || f_nco >= (int64_t)RX_NCO_MAX_HZ) continue;  
  
                        uint32_t frac   = div_q8 & 0xFFu;  
                        bool     is_int = (frac == 0);  
  
                        // --- П1: жёсткий запрет дырки в звуке [0..5000] ---  
                        if (f_nco >= (int64_t)RX_NCO_FORBID_LO &&  
                            f_nco <= (int64_t)RX_NCO_FORBID_HI) {  
                            // нелегален → только fallback; «меньшее зло» = ближе к 5 кГц  
                            uint64_t bad = (uint64_t)((int64_t)RX_NCO_FORBID_HI - f_nco);  
                            if (bad < fb_bad) {  
                                fb_bad = bad; fb_div_q8 = div_q8; fb_is_int = is_int;  
                                fb_best.refdiv=refdiv; fb_best.p1=p1; fb_best.p2=p2;  
                                fb_best.fbdiv=fbdiv; fb_best.clk_sys_hz=clk;  
                                fb_best.vsel=(uint32_t)vsel_for(clk);  
                                fb_best.is_oc=(clk > VFO_CLK_SYS_NOMINAL_HZ);  
                            }  
                            continue;  
                        }  
  
                        // --- стоимость легального кандидата ---  
                        uint64_t cost = 0;  
                        // П2: удаление от сладкой зоны  
                        if      (f_nco < (int64_t)RX_NCO_SWEET_LO)  
                            cost += (uint64_t)((int64_t)RX_NCO_SWEET_LO - f_nco) * W2;  
                        else if (f_nco > (int64_t)RX_NCO_SWEET_HI)  
                            cost += (uint64_t)(f_nco - (int64_t)RX_NCO_SWEET_HI) * W2;  
                        // П3: штраф за дробность  
                        if (!is_int) cost += W3;  
                        // П4: дробь подальше от k/8 (= кратных 32 в Q8)  
                        if (!is_int) {  
                            int32_t m    = (int32_t)frac % 32;       // 0..31  
                            int32_t dist = (m < 16) ? m : 32 - m;    // 0..16 до ближайшего k/8  
                            cost += (uint64_t)(16 - dist) * W4;      // ближе к k/8 → дороже  
                        }  
                        // П5: шина ближе к максимуму  
                        cost += ((clk_max - clk) / 1000000ull) * W5;  
  
                        if (cost < best_cost) {  
                            best_cost   = cost;  
                            best_div_q8 = div_q8;  
                            best_is_int = is_int;  
                            best_legal  = true;  
                            best.refdiv=refdiv; best.p1=p1; best.p2=p2;  
                            best.fbdiv=fbdiv; best.clk_sys_hz=clk;  
                            best.vsel=(uint32_t)vsel_for(clk);  
                            best.is_oc=(clk > VFO_CLK_SYS_NOMINAL_HZ);  
                        }  
                    }  
                }  
            }  
        }  
    }  
  
    // П6: ничего легального — берём «наименьшее зло» и честно предупреждаем.  
    if (!best_legal) {  
        Serial.println("[QUAD] ВНИМАНИЕ: нет кандидата с дыркой вне 0..5 кГц — "  
                       "ставлю наименьшее зло (дырка в полосе!)");  
        best        = fb_best;  
        best_div_q8 = fb_div_q8;  
        best_is_int = fb_is_int;  
    }
  
    // Прошиваем выбранную шину тем же путём, что TX (vreg + PLL + flash SSI).  
    // PLL-переключение рвёт тактирование Core1 — гасим его заранее.  
    multicore_reset_core1();  
    uint32_t vsel = best.vsel;  
    if (vsel == 0 || vsel < (uint32_t)VREG_VOLTAGE_1_10)  
        vsel = (uint32_t)vsel_for(best.clk_sys_hz);  
    vfo_set_clk_sys(best, vsel);  
  
    uint64_t clk_sys_hz = clock_get_hz(clk_sys);  
    uint32_t div_q8;  
    if (best_is_int) {  
        uint64_t D = (clk_sys_hz + 2ull * lo_hz) / (4ull * lo_hz);  
        if (D < 2)      D = 2;  
        if (D > 0xFFFF) D = 0xFFFF;  
        div_q8 = (uint32_t)(D << 8);                    // frac=0 — целый  
    } else {  
        uint64_t q = (clk_sys_hz * 256ull + 2ull * lo_hz) / (4ull * lo_hz);  
        if (q < (2u << 8))      q = 2u << 8;  
        if (q > (0xFFFFu << 8)) q = 0xFFFFu << 8;  
        div_q8 = (uint32_t)q;                           // дробный Q8 сохраняется  
    }  
    quad_lo_actual_hz = (uint32_t)((clk_sys_hz * 256ull) / (4ull * (uint64_t)div_q8));
  
    {  
        int32_t f_nco = (int32_t)freq_hz - (int32_t)quad_lo_actual_hz;  
        uint32_t frac = div_q8 & 0xFFu;  
        bool sweet = (f_nco >= (int32_t)RX_NCO_SWEET_LO &&  
                      f_nco <= (int32_t)RX_NCO_SWEET_HI);  
        Serial.printf("[QUAD] clk_sys=%lu, div=%lu+%lu/256 (%s), lo_actual=%lu, "  
                      "f_nco=%ld, sweet=%d\n",  
                      (unsigned long)clk_sys_hz,  
                      (unsigned long)(div_q8 >> 8), (unsigned long)frac,  
                      frac ? "дробный" : "целый",  
                      (unsigned long)quad_lo_actual_hz,  
                      (long)f_nco, sweet ? 1 : 0);  
        if (f_nco > 62500 || f_nco < -62500) {
            Serial.printf("[QUAD] ВНИМАНИЕ: |f_nco| > 62500 Гц (половина RX_FS_IN_HZ) — "  
                          "достижимая шина не позволяет подойти ближе, приём невозможен\n");  
        }  
    }  
    Serial.printf("[QUAD] Целевая %lu, целый делитель %lu, фактическая %lu\n",  
                  (unsigned long)lo_hz,  
                  (unsigned long)(div_q8 >> 8),  
                  (unsigned long)quad_lo_actual_hz);

    Serial.printf("[QUAD] Целевая %lu, целый делитель %lu, фактическая %lu\n",  
                  (unsigned long)lo_hz,  
                  (unsigned long)(div_q8 >> 8),  
                  (unsigned long)quad_lo_actual_hz);

    if (!quad_program_loaded) {  
        quad_offset = pio_add_program(lo_pio, &pio_quad_program);  
        quad_program_loaded = true;  
    }  
  
    quad_active = false;   // взводим до завершения переконфигурации  
  
    // Останавливаем SM и гасим core1 — дизеринг в RX не нужен,  
    // ядро уходит под DSP приёмника.  
    pio_sm_set_enabled(lo_pio, lo_sm, false);  
    multicore_reset_core1();  
    tone_changed = false;  
  
    // TX-пин: SM его больше не обслуживает — уводим в input,  
    // иначе на pin_freq_out останется защемлённый последний уровень.  
    pio_sm_set_consecutive_pindirs(lo_pio, lo_sm, pin_freq_out, 1, false);  
    gpio_set_dir(pin_freq_out, GPIO_IN);  
  
    pio_sm_config cq = pio_get_default_sm_config();  
    sm_config_set_wrap(&cq, quad_offset + 0, quad_offset + 3);  
    sm_config_set_set_pins(&cq, pin_freq_out_i, 2);   // Q = pin_freq_out_i + 1  
    // Делитель в конфиге: 24.8 -> float, SDK упакует в регистр при sm_init  
    sm_config_set_clkdiv(&cq, (float)div_q8 / 256.0f);  
    pio_gpio_init(lo_pio, pin_freq_out_i);  
    pio_gpio_init(lo_pio, pin_freq_out_q);  
  
    pio_sm_init(lo_pio, lo_sm, quad_offset, &cq); 
    // Направление ставим ПОСЛЕДНИМ, после sm_init — пины не должны  
    // выпускать полуинициализированные переходы в смеситель.  
    pio_sm_set_consecutive_pindirs(lo_pio, lo_sm, pin_freq_out_i, 2, true);  
    pio_sm_restart(lo_pio, lo_sm);          // PC -> wrap_target, чистая фаза  
    pio_sm_set_enabled(lo_pio, lo_sm, true);  
  
    quad_active = true;  
}

// Вернуть VFO в штатный TX-режим (2-тактовый меандр на одном пине).  
void vfo_quadrature_stop(uint32_t freq_hz, double step_hz) {  
    pio_sm_set_enabled(lo_pio, lo_sm, false);  
    // оба квадратурных пина в input до переконфигурации SM под передачу  
    pio_sm_set_consecutive_pindirs(lo_pio, lo_sm, pin_freq_out_i, 2, false);  
    pio_sm_set_enabled(lo_pio, lo_sm, false);
    quad_active = false;  
    vfo_hardware_init(freq_hz, step_hz);   // вернёт square-программу и TX-сетку  
}

void quad_test(uint32_t freq_hz) {
    Serial.printf("[QUAD] lo_target=%lu Hz  lo_actual=%lu Hz  err=%ld Hz\n",  
                freq_hz - 3000, vfo_quadrature_lo_hz(),  
                (long)(freq_hz - 3000) - (long)vfo_quadrature_lo_hz());  
    Serial.printf("[QUAD] clkdiv=0x%08lX  div=%lu.%02u  sm_cs=0x%08lX\n",  
                (unsigned long)lo_pio->sm[lo_sm].clkdiv,  
                (unsigned long)(lo_pio->sm[lo_sm].clkdiv >> 24),  
                (unsigned)((lo_pio->sm[lo_sm].clkdiv >> 16) & 0xFF),  
                (unsigned long)lo_pio->sm[lo_sm].execctrl);
}

// Этап 0 отладки квадратурного LO: дамп всего состояния PIO/SM,  
// что генерирует фазы на GP1/GP2.  
void vfo_quadrature_debug(void) {  
#define QUAD_LO_PIN_I 1
#define QUAD_LO_PIN_Q 2
    // Реальная частота шины: меряем счётчиком, не доверяем current_clk_sys_hz  
    uint32_t meas_clk = frequency_count_khz(CLOCKS_FC0_SRC_VALUE_CLK_SYS) * 1000u;  
    uint32_t cdiv   = lo_pio->sm[lo_sm].clkdiv;  
  
    Serial.printf("[LODBG] clk_sys: cached=%lu kHz  measured=%lu kHz\n",  
                  (unsigned long)(clock_get_hz(clk_sys)/1000ULL),  
                  (unsigned long)(meas_clk / 1000u));  
    Serial.printf("[LODBG] PIO=%d SM=%d  clkdiv=0x%08lX (int=%lu frac=%lu)\n",  
                  pio_get_index(lo_pio), (int)lo_sm,  
                  (unsigned long)cdiv,  
                  (unsigned long)(cdiv >> 16),  
                  (unsigned long)((cdiv >> 8) & 0xFF));  
    Serial.printf("[LODBG] SM ctrl=0x%08lX enabled=%d  execctrl=0x%08lX  shiftctrl=0x%08lX\n",  
                  (unsigned long)lo_pio->ctrl,  
                  (int)((lo_pio->ctrl & (1u << lo_sm)) != 0),   // <-- запятая  
                  (unsigned long)lo_pio->sm[lo_sm].execctrl,  
                  (unsigned long)lo_pio->sm[lo_sm].shiftctrl);
    // Функция пинов LO — должна быть PIO (F=pio0/pio1), не SIO  
    Serial.printf("[LODBG] GP%d func=%lu  GP%d func=%lu  pads: out_en=%d/%d\n",  
                  QUAD_LO_PIN_I, (unsigned long)(io_bank0_hw->io[QUAD_LO_PIN_I].ctrl & IO_BANK0_GPIO0_CTRL_FUNCSEL_BITS),  
                  QUAD_LO_PIN_Q, (unsigned long)(io_bank0_hw->io[QUAD_LO_PIN_Q].ctrl & IO_BANK0_GPIO0_CTRL_FUNCSEL_BITS),  
                  (int)((pads_bank0_hw->io[QUAD_LO_PIN_I] & PADS_BANK0_GPIO0_OD_BITS) == 0),  
                  (int)((pads_bank0_hw->io[QUAD_LO_PIN_Q] & PADS_BANK0_GPIO0_OD_BITS) == 0));  
    Serial.printf("[LODBG] lo_hz cached=%lu\n",  
                  (unsigned long)vfo_quadrature_lo_hz());  
    Serial.printf("[QUAD] clkdiv_hw=0x%08lX execctrl=0x%08lX pinctrl=0x%08lX instr=0x%04lX\n",  
                  (unsigned long)lo_pio->sm[lo_sm].clkdiv,  
                  (unsigned long)lo_pio->sm[lo_sm].execctrl,  
                  (unsigned long)lo_pio->sm[lo_sm].pinctrl,  
                  (unsigned long)lo_pio->sm[lo_sm].instr);
}






// ============================================================================
// ГЕНЕРАТОР ТОЧНОГО СИГНАЛА ПЕРЕДАТЧИКА: 2-тактовая программа
// ============================================================================

static uint64_t vfo_base_mhz = 0;   // базовый тон сетки, мГц  
static uint64_t vfo_step_mhz = 0;   // шаг сетки, мГц

// Ассемблерная микропрограмма PIO для меандра (цикл из 2 тактов)  
static const uint16_t pio_square_instructions[] = {
    0xe001,
    0xe000 
};
static const pio_program_t pio_square_program = {   
    .instructions = pio_square_instructions,   
    .length = 2,   
    .origin = -1,  
    .pio_version = 0   
};

static void __not_in_flash_func(vfo_set_clk_sys)(const PllConfig& cfg_in, uint32_t vsel) {
    PllConfig cfg = cfg_in;  
    if (cfg.refdiv == 0) cfg.refdiv = 1;   // защита от неинициализированного поля

    // p1=1 недокументированно делит пополам на VCO < ~2.8 ГГц — отклоняем такие конфиги  
        if (cfg.p1 < 2) {  
    #if VFO_PLL_DEBUG  
            Serial.printf("[PLL] REJECT: p1=%lu forbidden — fallback nominal\n",  
                        (unsigned long)cfg.p1);  
    #endif  
            cfg = pll_nominal;  
        }

    uint32_t target_clk_hz = (uint32_t)(((uint64_t)cfg.fbdiv * vfo_calibrated_xosc_hz()) / (uint64_t)(cfg.refdiv * cfg.p1 * cfg.p2));  
    bool is_overclocking = (target_clk_hz > current_clk_sys_hz);  
  
    if (is_overclocking) {  
        vreg_set_voltage((vreg_voltage)vsel);  
        busy_wait_us(500);  
    }  

    detach_peripheral_clock();  
    uint32_t ints_status = save_and_disable_interrupts();  
  
    // clk_sys -> XOSC 12 МГц (SCK флэша 6 МГц, безопасно)  
    clock_configure(clk_sys,  
                    CLOCKS_CLK_SYS_CTRL_SRC_VALUE_CLKSRC_CLK_SYS_AUX,  
                    CLOCKS_CLK_SYS_CTRL_AUXSRC_VALUE_XOSC_CLKSRC,  
                    vfo_calibrated_xosc_hz(), vfo_calibrated_xosc_hz());  
    // Округление ВВЕРХ до следующего кратного ref_hz: гарантирует, что внутреннее  
    // целочисленное деление pll_init даст ровно cfg.fbdiv, а не fbdiv-1  
    // (иначе при скорректированном XOSC < 12 МГц произведение падает ниже порога).  
    uint64_t ref_hz = ((uint64_t)vfo_calibrated_xosc_hz() + cfg.refdiv - 1u) / cfg.refdiv;  
    uint32_t vco_nominal_hz = (uint32_t)(ref_hz * (uint64_t)cfg.fbdiv);


// перед pll_init — что реально стоит в опоре PLL (CS bits 5:0 = refdiv)  
#if PLL_RUNTIME_DEBUG  
    Serial.printf("[PLL] pre: CS=0x%08lX refdiv_hw=%lu XOSC=%lu kHz\n",  
                  (unsigned long)pll_sys_hw->cs,  
                  (unsigned long)(pll_sys_hw->cs & PLL_CS_REFDIV_BITS),  
                  (unsigned long)frequency_count_khz(CLOCKS_FC0_SRC_VALUE_XOSC_CLKSRC));  
#endif  

    uint32_t cs_pre  = pll_sys_hw->cs;

    pll_init(pll_sys, cfg.refdiv, vco_nominal_hz, cfg.p1, cfg.p2);  

    // === АППАРАТНЫЙ МОНИТОРИНГ ЗАЩЁЛКИ ФАЗЫ PLL (LOCK BIT) ===
    // Ждем взвода бита LOCK в регистре CS системной PLL
    // Если аналоговая петля не успеет стабилизироваться за 2000 итераций — мы разорвем цикл, 
    // чтобы ядро не зависло намертво в глухом дедлоке.
    uint32_t timeout = 20000;  
    while (!(pll_sys_hw->cs & PLL_CS_LOCK_BITS) && --timeout);  
    bool pll_locked = (timeout != 0);

    // === BAUDR: ОГРАНИЧЕНИЕ НА ТАКТИРОВАНИЕ ФЛЭША СТРОГО <= 48 МГц ===  
    // Меняем VFO_FLASH_SCK_MAX_HZ на жесткие 48 000 000 Гц
    const uint32_t FLASH_SAFE_MAX_HZ = 48000000u;
    uint32_t ssi_baud = (uint32_t)((target_clk_hz + FLASH_SAFE_MAX_HZ - 1) / FLASH_SAFE_MAX_HZ);  
    
    ssi_baud = (ssi_baud + 1u) & ~1u;   // Округление вверх до ближайшего четного (требование аппаратного SSI)  
    if (ssi_baud < 2u)  ssi_baud = 2u;  
    if (ssi_baud > 34u) ssi_baud = 34u;  
    
    ssi_hw->ssienr = 0;                 // выключить SSI — иначе baudr не запишется  
    ssi_hw->baudr  = ssi_baud;  
    ssi_hw->ssienr = 1;                 // включить обратно  
  
    // clk_sys -> PLL_SYS (целевая частота)  
    clock_configure(clk_sys,  
                    CLOCKS_CLK_SYS_CTRL_SRC_VALUE_CLKSRC_CLK_SYS_AUX,  
                    CLOCKS_CLK_SYS_CTRL_AUXSRC_VALUE_CLKSRC_PLL_SYS,  
                    target_clk_hz, target_clk_hz);  
  
    restore_interrupts(ints_status);

#if PLL_RUNTIME_DEBUG  
    Serial.printf("[PLL] pre: CS=0x%08lX refdiv_hw=%lu\n",  
                  (unsigned long)cs_pre,  
                  (unsigned long)(cs_pre & PLL_CS_REFDIV_BITS));  

    // подтверждающий замер через 20 мкс после коммутации мультиплексора  
    busy_wait_us(20);  
    uint32_t post_khz = frequency_count_khz(CLOCKS_FC0_SRC_VALUE_CLK_SYS);  
    Serial.printf("[PLL] post-switch clk=%u kHz (expect=%u kHz)\n",  
                  (unsigned)post_khz, (unsigned)(cfg.clk_sys_hz / 1000u));  
#endif
 
    // --- Самопроверка: при промахе повторяем ВЕСЬ цикл переключения ---  
    bool locked_ok = false;
    uint32_t meas_khz = 0;                                   // <-- сюда  
    uint32_t expect_khz = cfg.clk_sys_hz / 1000u;  

    for (int attempt = 0; attempt < 3; attempt++) {    
            busy_wait_us(300);    
            meas_khz = frequency_count_khz(CLOCKS_FC0_SRC_VALUE_CLK_SYS);   // без uint32_t!  
            if (meas_khz > expect_khz * 997u / 1000u &&      
                meas_khz < expect_khz * 1003u / 1000u) {  
                locked_ok = true;    
                break;    
            }
#if PLL_RUNTIME_DEBUG  
        Serial.printf("[PLL] MISMATCH: meas=%u kHz expect=%u kHz — retry %d\n",  
                      (unsigned)meas_khz, (unsigned)expect_khz, attempt);  
#endif  
        // полный ре-секвенс: назад на XOSC, переинициализация PLL, вперёд на PLL_SYS

        uint32_t ints2 = save_and_disable_interrupts();
        clock_configure(clk_sys,  
                        CLOCKS_CLK_SYS_CTRL_SRC_VALUE_CLKSRC_CLK_SYS_AUX,  
                        CLOCKS_CLK_SYS_CTRL_AUXSRC_VALUE_XOSC_CLKSRC,  
                        vfo_calibrated_xosc_hz(), vfo_calibrated_xosc_hz());  
        pll_init(pll_sys, cfg.refdiv, vco_nominal_hz, cfg.p1, cfg.p2);  
        timeout = 20000;  
        while (!(pll_sys_hw->cs & PLL_CS_LOCK_BITS) && --timeout);
// DIAG: лок есть, но шина не та — либо микс postdiv, либо ложный замер  
#if VFO_PLL_DEBUG  
        Serial.printf("[PLL] retry-dbg: LOCK=%d CS=0x%08lX FB=%lu PRIM=0x%08lX meas=%u kHz\n",  
                      (int)(pll_sys_hw->cs & PLL_CS_LOCK_BITS ? 1 : 0),  
                      (unsigned long)pll_sys_hw->cs,  
                      (unsigned long)pll_sys_hw->fbdiv_int,  
                      (unsigned long)pll_sys_hw->prim,  
                      (unsigned)meas_khz);  
#endif
        clock_configure(clk_sys,  
                        CLOCKS_CLK_SYS_CTRL_SRC_VALUE_CLKSRC_CLK_SYS_AUX,  
                        CLOCKS_CLK_SYS_CTRL_AUXSRC_VALUE_CLKSRC_PLL_SYS,  
                        target_clk_hz, target_clk_hz);
        restore_interrupts(ints2);
    }
uint32_t meas_khz_final = meas_khz; 
#if PLL_RUNTIME_DEBUG  
    if (!locked_ok) {  
        Serial.printf("[PLL] FALLBACK reason: pll_locked=%d last_meas=%u expect=%u kHz\n",  
                      (int)pll_locked, (unsigned)meas_khz_final, (unsigned)expect_khz);  
    }  
#endif

    if (!locked_ok) {  
        // 3 промаха подряд — безопасный откат на номинал,  
        // чтобы таблица тонов не считалась от несуществующей частоты  
#if PLL_RUNTIME_DEBUG  
        Serial.printf("[PLL] FAIL x3 — fallback to nominal\n");  
#endif  
        clock_configure(clk_sys,    
                        CLOCKS_CLK_SYS_CTRL_SRC_VALUE_CLKSRC_CLK_SYS_AUX,    
                        CLOCKS_CLK_SYS_CTRL_AUXSRC_VALUE_XOSC_CLKSRC,    
                        vfo_calibrated_xosc_hz(), vfo_calibrated_xosc_hz());    

        uint64_t ref_hz_fb = ((uint64_t)vfo_calibrated_xosc_hz() + pll_nominal.refdiv - 1u)  
                            / pll_nominal.refdiv;  
        pll_init(pll_sys, pll_nominal.refdiv,  
                (uint32_t)(ref_hz_fb * (uint64_t)pll_nominal.fbdiv),  
                pll_nominal.p1, pll_nominal.p2);

        timeout = 20000;    
        while (!(pll_sys_hw->cs & PLL_CS_LOCK_BITS) && --timeout);    
        clock_configure(clk_sys,    
                        CLOCKS_CLK_SYS_CTRL_SRC_VALUE_CLKSRC_CLK_SYS_AUX,    
                        CLOCKS_CLK_SYS_CTRL_AUXSRC_VALUE_CLKSRC_PLL_SYS,    
                        pll_nominal.clk_sys_hz, pll_nominal.clk_sys_hz);    
        current_clk_sys_hz = pll_nominal.clk_sys_hz;    
        return;    
    }
  
    //current_clk_sys_hz = cfg.clk_sys_hz;
    current_clk_sys_hz = meas_khz * 1000u;   // реальность, а не желаемое cfg.clk_sys_hz



#if PLL_RUNTIME_DEBUG
Serial.printf("[PLL] sys_ctrl=0x%08lX selected=0x%02lX\n",  
                  (unsigned long)clocks_hw->clk[clk_sys].ctrl,  
                  (unsigned long)clocks_hw->clk[clk_sys].selected);

    if (!pll_locked) {  
        Serial.printf("[PLL] !!! NO LOCK: fbdiv=%lu target=%lu Hz — выход НЕДОСТОВЕРЕН\n",  
                    (unsigned long)cfg.fbdiv, (unsigned long)target_clk_hz);
    }  
    uint32_t real_clk = frequency_count_khz(CLOCKS_FC0_SRC_VALUE_CLK_SYS) * 1000u;  
    Serial.printf("[PLL] measured clk_sys=%lu Hz (target %lu)\n",  
                (unsigned long)real_clk, (unsigned long)target_clk_hz);
#endif
  
    if (!is_overclocking) {  
        busy_wait_us(100);  
        vreg_set_voltage((vreg_voltage)vsel);  
    }  
#if PLL_RUNTIME_DEBUG
Serial.printf("[PLL] CS=0x%08lX (refdiv=%lu)  FB=%lu  PRIM=0x%08lX\n",  
              (unsigned long)pll_sys_hw->cs,  
              (unsigned long)(pll_sys_hw->cs & PLL_CS_REFDIV_BITS),  
              (unsigned long)pll_sys_hw->fbdiv_int,  
              (unsigned long)pll_sys_hw->prim);
#endif 
  
    current_clk_sys_hz = cfg.clk_sys_hz;  
}


void vfo_clk_boost_enter(unsigned int target_freq_hz) {  
    if (target_freq_hz == 0) {  
        clk_boosted = true;  
        return;  
    }  
  
    // 1. Поиск оптимума (один проход)  
    PllConfig opt = vfo_find_optimal_pll(target_freq_hz, vfo_effective_clk_max());  
  
    // 2. Сравнение метрик  
    uint64_t target_mhz = (uint64_t)target_freq_hz * 1000ULL;  
    VfoParameters dummy;  
    uint64_t metric_opt = vfo_pll_metric(opt.clk_sys_hz,     target_mhz, &dummy);  
    uint64_t metric_cur = vfo_pll_metric(current_clk_sys_hz, target_mhz, &dummy);  
  
    if (metric_opt >= metric_cur || opt.clk_sys_hz == current_clk_sys_hz) {    
        cached_base_freq_hz = target_freq_hz;  
        vfo_base_mhz = (uint64_t)target_freq_hz * 1000ULL;   // мГц  
        
        // 1. Перестраиваем таблицу под новые параметры
        vfo_rebuild_tone_table(vfo_base_mhz, vfo_step_mhz);  
        
        // 2. Записываем новые pio_int/pio_frac/dds_step в защищенные спинлоком переменные.
        // vfo_set_tone_instant(0) внутри себя взведет флаг tone_changed = true!
        vfo_set_tone_instant(0);  
        
        // 3. Даем микропаузу, чтобы Core 1 в своем горячем цикле гарантированно 
        // увидел флаг tone_changed, сбросил аккумуляторы и применил новый шаг БЕЗ перезапуска ядра.
        busy_wait_us(10); 

#if BOOST_DEBUG 
        Serial.printf("[BOOST  ] SKIP-RETUNE (SOFT TUNE) clk=%lu kHz  target=%lu Hz\n",  
                      (unsigned long)(current_clk_sys_hz / 1000ULL),  
                      (unsigned long)target_freq_hz);  
#endif
        return;    
    }
  
    // 3. Остановка Core 1 — нужна и при ретюне (PLL-переключение рвёт тактирование)  
    multicore_reset_core1();  
    busy_wait_us(100);  
    cached_base_freq_hz = target_freq_hz; 
  
    // 4. Напряжение: профиль поиска с подстраховкой таблицей  
    uint32_t vsel = opt.vsel;  
    if (vsel == 0 || vsel < (uint32_t)VREG_VOLTAGE_1_10) {  
        vsel = (uint32_t)vsel_for(opt.clk_sys_hz);  
    }  
  
    // 5. Сдвиг частоты и питания (внутри: детач clk_peri, сброс PLL)  
    vfo_set_clk_sys(opt, vsel);  
  
    // 6. Пересчёт таблиц под новую clk_sys  
    vfo_rebuild_tone_table(vfo_base_mhz, vfo_step_mhz);  
    vfo_set_tone_instant(0);  
    tone_changed = true;          // страховка для Core 1  
  
    multicore_launch_core1(vfo_core1_entry);  
  
    // Правильный расчет VCO для вывода на экран в мегагерцах [Скорректировано]
    uint32_t vco_print_mhz = (uint32_t)(((uint64_t)opt.fbdiv * vfo_calibrated_xosc_hz()) / (1000000ULL * opt.refdiv));

#if BOOST_DEBUG
    Serial.printf("[BOOST  ] ON   clk_sys=%7.3f MHz  refdiv=%lu  fbdiv=%3lu  p1=%lu  p2=%lu  VCO=%4lu MHz  VSEL=%4u mV  FLASH=%6.3f MHz (BAUDR=%u)\n",  
                opt.clk_sys_hz / 1000000.0,  
                (unsigned long)opt.refdiv,
                (unsigned long)opt.fbdiv,  
                (unsigned long)opt.p1,  
                (unsigned long)opt.p2,  
                (unsigned long)vco_print_mhz,  
                (unsigned)vsel_to_mv(vsel),  
                opt.clk_sys_hz / 1000000.0 / (double)ssi_hw->baudr,  
                (unsigned)ssi_hw->baudr);  
#endif
    clk_boosted = true;
}


  

void vfo_clk_boost_exit(void) {    
    if (!clk_boosted) return;    
    
    vfo_set_clk_sys(pll_nominal, VREG_VOLTAGE_DEFAULT);  
    vfo_rebuild_tone_table((uint64_t)cached_base_freq_hz * 1000ULL,    
                        (uint64_t)(cached_step_hz * 1000.0));  
    
    // Пересчёт таблицы тонов обратно под номинальную clk_sys    
    uint32_t save = spin_lock_blocking(vfo_spin_lock);    
    uint64_t base_mhz = (uint64_t)cached_base_freq_hz * 1000ULL;    
    uint64_t step_mhz = (uint64_t)(cached_step_hz * 1000.0);    
    for (int i = 0; i < VFO_TONES_COUNT; i++) {    
        vfo_tones[i] = calculate_raw_params_mhz(current_clk_sys_hz,    
                                                 base_mhz + (uint64_t)i * step_mhz);    
    }    
    current_active_tone = VFO_TONE_NONE;    
    tone_changed = true;    
    spin_unlock(vfo_spin_lock, save);  
  
    // VCO = XOSC * fbdiv / refdiv (uint64 — fbdiv до 320 * 12 МГц не влезает в uint32 впритык)  
    uint64_t vco_mhz = (vfo_calibrated_xosc_hz() * (uint64_t)pll_nominal.fbdiv)  
                       / ((uint64_t)pll_nominal.refdiv * 1000000ULL);  

#if BOOST_DEBUG
    Serial.printf("[BOOST  ] OFF  clk_sys=%7.3f MHz  refdiv=%lu  fbdiv=%3lu  p1=%lu  p2=%lu  VCO=%4llu MHz  VSEL=%4u mV  FLASH=%6.3f MHz (BAUDR=%u)  T_CPU=%5.1f C\n",    
                  pll_nominal.clk_sys_hz / 1000000.0,  
                  (unsigned long)pll_nominal.refdiv,  
                  (unsigned long)pll_nominal.fbdiv,    
                  (unsigned long)pll_nominal.p1,    
                  (unsigned long)pll_nominal.p2,    
                  (unsigned long long)vco_mhz,    
                  (unsigned)vsel_to_mv((uint32_t)VREG_VOLTAGE_DEFAULT),    
                  pll_nominal.clk_sys_hz / 1000000.0 / (double)ssi_hw->baudr,    
                  (unsigned)ssi_hw->baudr,    
                  (double)0.0);
#endif
    clk_boosted = false;
}




// Точка входа второго ядра (Core 1): бесконечный горячий цикл дизеринга.  
static void __not_in_flash_func(vfo_core1_entry)() {
    // Локальные резидентные копии параметров тона
    int32_t  l_step  = 0;
    int32_t  l_int   = 8;
    int32_t  l_frac  = 0;
    uint32_t l_dmask = 0;

    // Состояние накопителей
    uint32_t loc_acc1 = 0;
    uint32_t loc_acc2 = 0;
    uint32_t loc_m2_carry_prev = 0;
    uint32_t loc_rand_state = xorshift_state;

    // Прямой указатель на регистр SM PIO
    volatile uint32_t *clkdiv_reg = &lo_pio->sm[lo_sm].clkdiv;

    const uint32_t poll_mask = (1u << 6) - 1u;
    uint32_t poll_cnt = 0; 

    while (true) {
        // Разряженный опрос флага обмена данными (внутри лога)
        if ((poll_cnt & poll_mask) == 0u) {  
            if (__builtin_expect(tone_changed, 0)) {  
                uint32_t save = spin_lock_blocking(vfo_spin_lock);
                l_step  = (int32_t)dds_step;
                l_int   = (int32_t)target_pio_int;
                l_frac  = (int32_t)target_pio_frac8;
                l_dmask = vfo_frac_dither_mask;
                if (dither_reset_pending) {  
                    // Полный сброс: только при инициализации/перестройке VFO  
                    loc_acc1 = 0;  
                    loc_acc2 = 0;  
                    loc_m2_carry_prev = 0;  
                    loc_rand_state = xorshift_state;  
                    dither_reset_pending = false;  
                }  
                // При обычной смене тона аккумуляторы сохраняются — фаза не прыгает.
                tone_changed = false; 
                spin_unlock(vfo_spin_lock, save);
            }  
        }  
        poll_cnt++;

        // === 1. ГПСЧ XORSHIFT32 (Чистый Си, компилируется в 6 инструкций) ===
        loc_rand_state ^= loc_rand_state << 13;
        loc_rand_state ^= loc_rand_state >> 17;
        loc_rand_state ^= loc_rand_state << 5;

        // === 2. ДИЗЕРИНГ ЦЕЛОЙ ЧАСТИ ШАГА (4 бита RPDF) ===
        int32_t r_bits = (int32_t)(loc_rand_state & 0x0Fu);
        int32_t step = l_step + ((r_bits << 1) - 15);

        int32_t total_correction = 0;

        // === 3. АВТОНОМНОЕ ПЕРЕКЛЮЧЕНИЕ ПОРЯДКА MASH ===
        if (l_dmask == 0u) {
            // ВЧ-РЕЖИМ: Однокаскадный жесткий MASH-1 (0 или +1)
            uint32_t old_acc = loc_acc1;
            loc_acc1 += (uint32_t)step;
            // Беззнаковое сравнение компилятор гарантированно соберет в команду извлечения Carry
            total_correction = (loc_acc1 < old_acc); 
        } else {
            // НЧ-РЕЖИМ: Каскадный прецизионный MASH-1-1
            // Используем встроенные функции GCC для извлечения аппаратного переполнения процессора
            uint32_t carry1 = __builtin_add_overflow(loc_acc1, (uint32_t)step, &loc_acc1) ? 1u : 0u;
            uint32_t carry2 = __builtin_add_overflow(loc_acc2, loc_acc1, &loc_acc2) ? 1u : 0u;
            
            total_correction = (int32_t)carry1 + (int32_t)carry2 - (int32_t)loc_m2_carry_prev;
            loc_m2_carry_prev = carry2;
        }

        // === 4. СБОРКА ТЕКУЩЕЙ ФРАКЦИИ ===
        int32_t current_frac = l_frac + total_correction;
        int32_t current_int  = l_int;

        // === 5. МАТЕМАТИЧЕСКИЙ ТРЕУГОЛЬНЫЙ TPDF ФРАК-ДИЗЕР ===
        if (l_dmask != 0u) {    
            uint32_t r1 = (loc_rand_state >> 8)  & l_dmask;    
            uint32_t r2 = (loc_rand_state >> 16) & l_dmask;    
            current_frac += (int32_t)(r1 + r2) - (int32_t)l_dmask;
        }

        // Выравнивание знака и переноса фракции (current_frac >> 8)
        // Для Cortex-M0+ знаковые сдвиги Си-компилятор переводит в нативную команду ASRS
        current_int  += (current_frac >> 8);   
        current_frac &= 0xFF; 

        // Финальная запись конфигурационного слова в регистр clkdiv PIO
        *clkdiv_reg = ((uint32_t)current_int << 16) | ((uint32_t)current_frac << 8);
    }
}


 
// Минимальное КОЛЬЦЕВОЕ расстояние dds_step до якорей k/8 (единицы 2^-32).  
// Якоря: k * 2^29, k = 0..7. Якорь 8/8 = 2^32 совпадает с 0 по кольцу —  
// кольцевая арифметика покрывает его автоматически.  
// Максимум результата = 2^28 (половина интервала k/8).  
static uint32_t dds_step_min_dist_to_k8(uint32_t step) {  
    uint32_t best = (1u << 28);          // 268435456 — теоретический максимум  
    for (uint32_t k = 0; k < 8; k++) {  
        uint32_t a = k << 29;            // якорь k/8 шкалы  
        uint32_t d = step - a;           // беззнаковая разность — уже на кольце  
        if (d > 0x80000000u) d = 0u - d; // min(d, 2^32 - d)  
        if (d < best) best = d;  
    }  
    return best;  
}


// штраф за мощность спура: pen = 2^30 · (A/16384) · (64/D)²  
static uint64_t frac_spur_power_pen(uint16_t pio_int, uint8_t pio_frac) {  
    if (pio_frac == 0) return 0;  
    uint64_t D_x256 = (uint64_t)pio_int * 256ULL + pio_frac;  
    uint64_t A      = (uint64_t)pio_frac * (256u - pio_frac);       // ≤16384  
    // сдвиг подобрать; 46 даёт ~1.6e10 на frac47/int25 и ~3e9 на frac213/int56
    uint64_t pen = ((uint64_t)A << 46) / (D_x256 * D_x256);
    return pen;  
}


static uint64_t vfo_pll_metric_verbose(uint64_t clk_sys_hz, uint64_t target_mhz,  
                                       MetricBreakdown *b, VfoParameters *out) {  
    VfoParameters test = calculate_raw_params_mhz(clk_sys_hz, target_mhz);  
    if (out) *out = test;  
  
    memset(b, 0, sizeof(MetricBreakdown));  
    b->frac = test.pio_frac;  
    b->raw_step = test.dds_step;  
  
    // 1. Идеальный узел: ни дробной части, ни остатка DDS  
    if (test.pio_frac == 0 && test.dds_step == 0) {  
        return 0;  
    }  
  
    // 1a. Уровень FRAC8-спура: штраф ~ A/D² (аналитический потолок линии)    
    // Отстройку спура считаем ОДИН раз и переиспользуем в level-пенальти ниже.    
    uint64_t spur_off = frac_spur_min_off_hz(test.pio_int, test.pio_frac, clk_sys_hz);    
  
    b->spur_power_pen = frac_spur_power_pen(test.pio_int, test.pio_frac);    
    if (spur_off != UINT64_MAX && spur_off < VFO_SPUR_HORIZON_HZ) {    
        uint64_t prox   = VFO_SPUR_HORIZON_HZ - spur_off;    
        uint64_t prox_q = prox / 1024ULL;    
        b->spur_power_pen += (prox_q * prox_q * prox_q) << 4;    
    }    
    b->total_metric += b->spur_power_pen;           // позиция спура учтена
  
    // 2. Цена frac=0: вся дробная работа ложится на MASH
    if (test.pio_frac == 0) {  
        uint64_t act = (test.dds_step <= (0xFFFFFFFFu - test.dds_step))  
                    ? (uint64_t)test.dds_step  
                    : (0xFFFFFFFFu - (uint64_t)test.dds_step);  
        uint64_t frac0_pen = (act >> 4) + (1ULL << 36);  
        b->total_metric += frac0_pen;  
    }  
  
    // 2b. Простые дроби FRAC8 → короткий период паттерна → когерентный спур  
    {  
        uint32_t f = test.pio_frac;  
        uint32_t ctz = (f == 0) ? 8 : (uint32_t)__builtin_ctz(f);  
        b->ctz_val = ctz;  
        if (ctz >= 5) {                                   // знаменатель ≤ 8  
            b->ctz_penalty = (1ULL << (ctz + 26)) + (1ULL << 33);  
        }  
        b->total_metric += b->ctz_penalty;  
    }  
  
    // 3. Подошва: clk·int к эталону 400M·55  
    {  
        const uint64_t DEN_REF = 400000000ULL * 55ULL;  
        uint64_t dens = clk_sys_hz * (uint64_t)test.pio_int;  
        if (dens < DEN_REF) {  
            b->clk_penalty = ((DEN_REF - dens) * (1ULL << 30)) / DEN_REF;  
        } else {  
            b->clk_penalty = 0;  
        }  
        b->total_metric += b->clk_penalty;  
    }  
  
    // 3b. Близость dds_step к якорям k/8 → idle-тоны MASH  
    if (test.dds_step != 0) {  
        uint32_t dist_k8 = dds_step_min_dist_to_k8(test.dds_step);  
        b->center_dist = dist_k8;  
        if (dist_k8 < VFO_K8_BELT) {  
            uint64_t deficit = (uint64_t)(VFO_K8_BELT - dist_k8);  
            b->mash_penalty = (deficit * deficit) >> 14;  
        }  
        b->total_metric += b->mash_penalty;  
    }  
  
    // 4. Запрет малых INT  
    if (test.pio_int < 4) {  
        b->int_penalty = VFO_INT_PENALTY;  
        b->total_metric += b->int_penalty;  
    }

    // Level-пенальти: спуры хуже -30 dBc дорожают квадратично,  
    // но с коэффициентом дальности kdist: у несущей штраф полный,  
    // за горизонтом ФНЧ — остаточный (спур давит фильтр).  
    if (test.pio_frac != 0 && test.pio_int != 0) {    
        float lvl_db = frac_spur_level_db(test.pio_int, test.pio_frac);    
        if (lvl_db > -30.0f) {    
            float over = lvl_db + 30.0f;    
            uint64_t base = (uint64_t)(over * over) << 22;    
  
            // Коэффициент дальности спура: переиспользуем spur_off из блока 1a    
            // (1.0 у несущей → 0.1 за горизонтом ФНЧ)    
            float kdist;    
            if      (spur_off == UINT64_MAX)          kdist = 1.0f;   // спура нет/на несущей    
            else if (spur_off >= VFO_SPUR_HORIZON_HZ) kdist = 0.1f;   // за горизонтом — остаточный    
            else kdist = 1.0f - 0.9f * ((float)spur_off / (float)VFO_SPUR_HORIZON_HZ);    
  
            uint64_t pen = (uint64_t)((double)base * kdist);    
            b->spur_power_pen += pen;    
            b->total_metric   += pen;    
        }    
    }

    return b->total_metric;  
}





// Прецизионный расчёт параметров PIO-делителя для целевой частоты  
//        в миллигерцах (0.001 Гц).  
// Вычисляет делитель автомата PIO в формате fixed-point Q8.8  
static VfoParameters calculate_raw_params_mhz(uint64_t clk_sys_hz, uint64_t mhz_target) {    
    // Границы КВ-диапазона в миллигерцах (1.0 .. 40.0 МГц)    
    if (mhz_target < 100000000ULL)   mhz_target = 100000000ULL;    
    if (mhz_target > 40000000000ULL) mhz_target = 40000000000ULL;    
    
    uint64_t clocks_per_period = 2ULL;    
    uint64_t vfo_denom = mhz_target * clocks_per_period;    
    
    // Делитель PIO в формате 16.8: int + frac8/256    
    uint64_t pio_div_fixed8 = ((clk_sys_hz * 256ULL) * 1000ULL) / vfo_denom;    
    uint8_t  frac8 = (uint8_t)(pio_div_fixed8 & 0xFFu);    
    
    VfoParameters params;    
    
    // Дробный режим: int=floor, frac=дробные 8 бит делителя    
    params.pio_int  = pio_div_fixed8 >> 8;    
    params.pio_frac = frac8;    
    
    // Для совместимости со структурой сохраняем в chz (сантигерцах)    
    params.target_freq_chz = (uint32_t)(mhz_target / 10ULL);    
    
    if (params.pio_int < 2) {    
        params.pio_int  = 2;    
        params.pio_frac = 0;    
    }    
    
    // Суб-LSB остаток: ошибка квантования ниже одного frac8-LSB делителя.    
    // Шаг в единицах "переносов на итерацию · 2^32".    
    uint64_t clk_sys_rem   = ((clk_sys_hz * 256ULL) * 1000ULL) % vfo_denom;    
    uint64_t intermediate  = (clk_sys_rem << 16) / vfo_denom;    
    uint64_t remainder_low = (clk_sys_rem << 16) % vfo_denom;    
    
    params.dds_step = (uint32_t)((intermediate << 16)    
                               + ((remainder_low << 16) / vfo_denom));    
    
    
    // Принудительная нечётность шага: gcd(dds_step, 2^32) = 1,    
    // период паттерна = 2^32 отсчётов → гребёнка превращается в шумовую полку.    
    if (params.dds_step != 0) params.dds_step |= 1u;    
    
   
    return params;    
}




// Метрика кандидата
static uint64_t vfo_pll_metric(uint64_t clk_sys_hz, uint64_t target_mhz, VfoParameters *out) {  
    MetricBreakdown b;  
    return vfo_pll_metric_verbose(clk_sys_hz, target_mhz, &b, out);  
}


// хелпер
// функция ищет ближайший к несущей FRAC8-спур среди первых 4 гармоник периода переполнения дробного байта
// для дробного делителя D = pio_int + pio_frac/256 
// clk_sys_hz - делимая частота системной шины
// pio_int    - целая часть делителя
// pio_frac   - дробная часть делителя
static uint64_t frac_spur_min_off_hz(uint16_t pio_int, uint8_t pio_frac, uint64_t clk_sys_hz) {
    // если деление целочисленное, то спуров нет
    if (pio_frac == 0) return UINT64_MAX;
    // базовый делитель PIO в масштабе fixed-point Q8.8
    uint64_t div_x256 = (uint64_t)pio_int * 256ULL + pio_frac;  
    // если пришёл ноль - выходим
    if (div_x256 == 0) return UINT64_MAX;
    // накопитель рекорда
    uint64_t best = UINT64_MAX;
    // Цикл перебор гармоник переполнения k = 1...4
    for (uint32_t k = 1; k <= 4; k++) {
        // Расчет фазовой периодичности (свёртка по модулю)
        uint32_t m  = ((uint32_t)pio_frac * k) & 0xFFu;  
        uint32_t fd = (m < 256u - m) ? m : 256u - m;    // результат в диапазоне 0..128  
        if (fd == 0) continue;                          // если гармоника попала на тон (нулевые биения) - пропускаем
        uint64_t off = clk_sys_hz * fd / div_x256;      // Отстройка гармоники, Гц
        if (off < best) best = off;                     // фиксация худшго рекорда
    }
    return best;
}


// Оценка уровня главной пары FRAC8-спуров, dBc.  
// Модель: пилообразная ФМ с глубиной Δφ = f·(256−f)/(256·D) такта VCO;  
// L1 ≈ 10·log10( f·(256−f) / (32·π²·D²) )  — потолок, без sinc-огибающей.  
static float frac_spur_level_db(uint16_t pio_int, uint8_t pio_frac) {  
    if (pio_frac == 0 || pio_int == 0) return -999.0f;   // спура нет  
    float D = (float)pio_int + (float)pio_frac / 256.0f;  
    float f = (float)pio_frac;  
    float p2 = f * (256.0f - f);                          // огибающая простоты дроби  
    // L1_raw = 10·log10(p2 / (32·π²·D²))  
    float lvl = 10.0f * log10f(p2 / (32.0f * 9.8696f * D * D));  
    return lvl - 21.0f;   // поправка, откалиброванная на 3-х измеренных точках  
}






PllConfig vfo_find_optimal_pll(unsigned int target_frequency_hz, uint64_t max_clk_limit) {  
  
    uint64_t crystal_hz = vfo_calibrated_xosc_hz();  
    uint64_t target_mhz = (uint64_t)target_frequency_hz * 1000ULL; // миллигерцы

    uint64_t clk_limit = (max_clk_limit == 0) ? vfo_effective_clk_max() : max_clk_limit;
  
    // Дефолтная безопасная конфигурация на случай сбоя  
    PllConfig best_pll = { 133, 6, 2, 133000000ULL, (uint32_t)VREG_VOLTAGE_DEFAULT, false, 1 };
    // Если в вашей PllConfig поля refdiv нет — уберите `1,` и строки присваивания refdiv ниже.  
  
    // Границы КВ-диапазона (1.0 .. 30.0 МГц) в миллигерцах  
    if (target_mhz < 1000000000ULL)  target_mhz = 1000000000ULL;  // 1.0 МГц  
    if (target_mhz > 30000000000ULL) target_mhz = 30000000000ULL; // 30 МГц  
  
    const uint64_t min_allowed_clk = VFO_CLK_SYS_MIN_HZ;    
    const uint64_t max_allowed_clk = clk_limit;       // = flash-лимит при max_clk_limit==0
  
#if VFO_PLL_DEBUG  
    Serial.printf("[PLLDBG] limits: clk_sys<=%.1f MHz, VCO<=%.0f MHz (flash)\n",  
              vfo_effective_clk_max() / 1e6, vfo_effective_pll_max() / 1e6);
    Serial.printf("[PLLDBG] scan range: %.3f .. %.3f MHz (target=%u)\n",  
              min_allowed_clk / 1e6, max_allowed_clk / 1e6, target_frequency_hz);  
    Serial.printf("[PLLDBG] target=%u Hz  nominal: clk=%lu\n",  
                  target_frequency_hz, (unsigned long)pll_nominal.clk_sys_hz);  
#endif  
  
    // ---- Классификаторы и состояние арбитража ----  
    uint64_t min_dds_metric    = UINT64_MAX;  // метрика победителя (не номинала!)  
    bool     best_forbidden    = true;        // класс победителя: frac в поясе  
    uint32_t n_arbit           = 0;           // сколько кандидатов дошло до арбитража  

    // --- отдельный трекер лучшего frac=0-кандидата ---  
    uint64_t best_frac0_metric   = UINT64_MAX;  
    uint64_t best_frac0_clk      = 0;  
    uint32_t best_frac0_fbdiv    = 0, best_frac0_p1 = 0, best_frac0_p2 = 0;  
    uint32_t best_frac0_refdiv   = 0;  
    uint32_t n_frac0_seen        = 0;      // сколько frac=0-кандидатов встретилось

#if VFO_PLL_DEBUG  
    // TOP-10 лог для диагностики (без дублей по clk_sys)  
    struct CandLog {  
        uint64_t clk, vco, metric, spur_off;  
        uint32_t fbdiv, p1, p2, refdiv, step;  
        uint16_t pio_int;  
        uint8_t  pio_frac;  
        bool     forbidden, clean;
        float    spur_lvl;          // оценка уровня главной FRAC8-пары, dBc
    };  
    CandLog top10[20];  
    for (int i = 0; i < 20; i++) top10[i].metric = UINT64_MAX, top10[i].clk = 0;  
#endif  
  
    // ---- Матричный скан: refdiv × fbdiv × (p1,p2) ----  
for (uint32_t refdiv = 1; refdiv <= 3; refdiv++) {  
    //uint32_t refdiv = 1;
    uint64_t ref_hz = crystal_hz / refdiv;   // REFDIV: 1,2,3 → 12,6,4 МГц  
  
        for (uint32_t p1 = 2; p1 <= 7; p1++) {   // p1 >= 2: режим p1=1 даёт ровное деление на 2 при VCO < ~2.8 ГГц  
            for (uint32_t p2 = 1; p2 <= 7; p2++) {  
                if (p1 < p2) continue;   // ВЧ-правило: старший постделитель первым,  
                                        // иначе PLL работает в режиме, который  
                                        // OCTEST никогда не проверял  
                uint32_t pdiv_total = p1 * p2;  
                for (uint32_t fbdiv = 16; fbdiv <= 320; fbdiv++) {  
                    uint64_t vco_hz = ref_hz * fbdiv;
  
                    // Только нижний предел VCO (даташит 750 МГц)
                    if (vco_hz < 750000000ULL) continue;
                    // Верхний предел
                    if (vco_hz > vfo_effective_pll_max()) continue;          // лимит VCO из flash (1600М…3.9Г)
                    
                    uint64_t clk_sys_hz = vco_hz / (uint64_t)pdiv_total;
                    if (clk_sys_hz < min_allowed_clk ||
                        clk_sys_hz > clk_limit) continue;                     // лимит clk_sys из flash (133М…400М)

                    // Жёсткий минимум шины: спур-уровень ~ f_out²/clk_sys
                    // if (clk_sys_hz < VFO_CLK_SYS_PREF_MIN_HZ) continue;
  
                    // Единая метрика кандидата (verbose-версия с декомпозицией штрафов)
                    VfoParameters test;
                    MetricBreakdown brk;
                    uint64_t current_dds_metric =
                        vfo_pll_metric_verbose(clk_sys_hz, target_mhz, &brk, &test);
  
                    if (test.pio_int < 2) continue;

                        // Гейт плотности коррекции clk·int. Потолок продукта физически ограничен:  
                        //   max(clk·int) ≈ clk_max² / (2·f_out).  
                        // Выше ~18 МГц фиксированный порог 4e9 недостижим и опустошает скан.  
                        // Берём min(4e9, 90% от достижимого максимума) — качество сохраняется,  
                        // но скан не пустеет никогда.  
                        {  
                            uint64_t f_out_hz = target_mhz / 1000ULL;                 // target_mhz — миллигерцы  
                            uint64_t prod_max = (max_allowed_clk * max_allowed_clk) / (2ULL * f_out_hz);  
                            uint64_t gate     = 4000000000ULL;  
                            uint64_t cap      = (prod_max * 9ULL) / 10ULL;            // 90% потолка  
                            if (gate > cap) gate = cap;  
                            if (clk_sys_hz * (uint64_t)test.pio_int < gate) continue;  
                        }  
  
                    // === КЛАСС 1: запретный пояс FRAC8 (многогармонический, k=1..4) ===
                    uint64_t spur_off_hz = frac_spur_min_off_hz(test.pio_int,
                                                                test.pio_frac,
                                                                clk_sys_hz);


                        bool simple_frac = false;  
                        // Вето простых дробей действует только на ВЧ/СЧ (малые/средние int).  
                        // На НЧ (большой int → большое D) гармоники простых дробей падают как ~1/D²,  
                        // спур уходит далеко и на железе не виден — вето отключаем.  
                        if (test.pio_frac != 0u && test.pio_int <= VFO_SIMPLE_FRAC_INT_MAX) {    
                            uint32_t danger_zone = (test.pio_int <= 14) ? 16u : 8u;

                            for (uint32_t n = 2; n <= 4 && !simple_frac; n++) {     
                                for (uint32_t k = 1; k < n; k++) {  
                                    uint32_t anchor = (k * 256u) / n;  
                                    uint32_t d = (test.pio_frac > anchor) ? test.pio_frac - anchor  
                                                                        : anchor - test.pio_frac;  
                                    if (d < danger_zone) { simple_frac = true; break; }  
                                }  
                            }
                        }

                        bool frac_forbidden = (test.pio_frac != 0u) &&  
                                            ((spur_off_hz < VFO_SPUR_MIN_OFFSET_HZ) || simple_frac);

  
                    // === КЛАСС 2: чистота дизера по СЫРОМУ dmin (до нормализации!) ===  
                    uint32_t dd  = test.dds_step;  
                    uint32_t dmin_raw = (dd < (uint32_t)(0u - dd)) ? dd  
                                                                   : (uint32_t)(0u - dd);  
                    bool candidate_clean = (dmin_raw < VFO_DMIN_CEILING);  
                    bool     cand_frac_zero = (test.pio_frac == 0u);  
                    uint32_t cand_d8 = dds_step_min_dist_to_k8(test.dds_step); 
                    n_arbit++;  

                    if (test.pio_frac == 0) {  
                        n_frac0_seen++;  
                        if (current_dds_metric < best_frac0_metric) {  
                            best_frac0_metric = current_dds_metric;  
                            best_frac0_clk    = clk_sys_hz;  
                            best_frac0_fbdiv  = fbdiv;  
                            best_frac0_p1     = p1;  
                            best_frac0_p2     = p2;  
                            best_frac0_refdiv = refdiv;  
                        }  
                    }

#if VFO_PLL_DEBUG  
                    // TOP-10 без дублей по clk_sys  
                    bool dup = false;  
                    for (int i = 0; i < 20; i++)  
                        if (top10[i].clk == clk_sys_hz) { dup = true; break; }  
                    if (!dup && current_dds_metric < top10[19].metric) {  
                        int pos = 19;  
                        while (pos > 0 && current_dds_metric < top10[pos-1].metric) pos--;  
                        for (int k = 19; k > pos; k--) top10[k] = top10[k-1];  
                        top10[pos].clk = clk_sys_hz;  top10[pos].vco = vco_hz;  
                        top10[pos].metric = current_dds_metric;  
                        top10[pos].fbdiv = fbdiv; top10[pos].p1 = p1;  
                        top10[pos].p2 = p2;         top10[pos].refdiv = refdiv;  
                        top10[pos].step = test.dds_step;  
                        top10[pos].pio_int = test.pio_int;  
                        top10[pos].pio_frac = test.pio_frac;  
                        top10[pos].spur_off = spur_off_hz;  
                        top10[pos].spur_lvl = frac_spur_level_db(test.pio_int,  
                                                                 test.pio_frac);  
                        top10[pos].forbidden = frac_forbidden;  
                        top10[pos].clean = candidate_clean;  
                    }  
#endif  
  
                    // === АРБИТРАЖ ===  
                    // Вето по запретному поясу FRAC8: кандидат с simple_frac  
                    // или спуром < VFO_SPUR_MIN_OFFSET_HZ не может выиграть,  
                    // если существует хотя бы один незапретный кандидат.  
                    // Реализуем как доминирующий штраф — заодно сохраняется  
                    // fallback, если ВСЕ кандидаты запретные.  
                    uint64_t arb_metric = current_dds_metric;    
                    if (frac_forbidden) arb_metric += (1ULL << 40);    
                    // frac=0 с остаточным dds_step — близкий idle-тон DDS/MASH,    
                    // который ФНЧ НЕ снимает (отстройка ~единицы кГц из-за    
                    // кварцевой коррекции — точного целого попадания нет).    
                    // Штраф строго выше запретного пояса FRAC8 (2^42 > 2^40),    
                    // чтобы любой дробный кандидат с фильтруемым спуром побеждал.    
                    if (test.pio_frac == 0u && test.dds_step != 0u)    
                        arb_metric += (1ULL << 42);    
    
                    bool prefer = (arb_metric < min_dds_metric) ||    
                                  (arb_metric == min_dds_metric &&    
                                   clk_sys_hz > best_pll.clk_sys_hz);
  
                    if (prefer) {    
                        best_forbidden  = frac_forbidden;    
                        min_dds_metric  = arb_metric;    
  
                        best_pll.fbdiv      = fbdiv;  
                        best_pll.p1         = p1;  
                        best_pll.p2         = p2;  
                        best_pll.refdiv     = refdiv;
                        best_pll.clk_sys_hz = clk_sys_hz;  
                        best_pll.vsel       = (uint32_t)vsel_for(clk_sys_hz);  
                        best_pll.is_oc      = (clk_sys_hz > VFO_CLK_SYS_NOMINAL_HZ);  
                    }  
                }  
            }  
        }
    }

#if VFO_PLL_DEBUG
    Serial.printf("[PLLDBG] frac0: seen=%lu", (unsigned long)n_frac0_seen);  
    if (n_frac0_seen) {  
        Serial.printf("  best: clk=%.3f MHz refdiv=%lu fbdiv=%lu p1=%lu p2=%lu metric=%llu\n",  
                      best_frac0_clk / 1e6,  
                      (unsigned long)best_frac0_refdiv,  
                      (unsigned long)best_frac0_fbdiv,  
                      (unsigned long)best_frac0_p1,  
                      (unsigned long)best_frac0_p2,  
                      (unsigned long long)best_frac0_metric);  
    } else {  
        Serial.printf("  (нет frac=0-кандидатов на этой сетке)\n");  
    }  
#endif

    // === ЗАЩИТА ОТ ПУСТОГО СКАНА: встаём на макс. доказанный flash-clk ===  
    if (n_arbit == 0) {  
        // Ищем наивысший clk_sys <= flash-лимита с валидными делителями.  
        // Границы VCO те же, что в основном скане (750 МГц .. flash-VCO).  
        uint64_t fb_clk_target = vfo_effective_clk_max();   // доказанный потолок clk  
        uint64_t best_fb_clk   = 0;  
        PllConfig fb_pll       = best_pll;                   // стартуем с дефолта 133M  
  
        for (uint32_t refdiv = 1; refdiv <= 3; refdiv++) {  
            uint64_t ref_hz = crystal_hz / refdiv;  
            for (uint32_t p1 = 2; p1 <= 7; p1++) {  
                for (uint32_t p2 = 1; p2 <= 7; p2++) {  
                    if (p1 < p2) continue;  
                    uint32_t pdiv_total = p1 * p2;  
                    for (uint32_t fbdiv = 16; fbdiv <= 320; fbdiv++) {  
                        uint64_t vco_hz = ref_hz * fbdiv;  
                        if (vco_hz < 750000000ULL) continue;  
                        if (vco_hz > vfo_effective_pll_max()) continue;  
                        uint64_t clk_sys_hz = vco_hz / (uint64_t)pdiv_total;  
                        if (clk_sys_hz < min_allowed_clk) continue;  
                        if (clk_sys_hz > fb_clk_target)   continue;   // не выше доказанного  
                        if (clk_sys_hz > best_fb_clk) {  
                            best_fb_clk        = clk_sys_hz;  
                            fb_pll.fbdiv       = fbdiv;  
                            fb_pll.p1          = p1;  
                            fb_pll.p2          = p2;  
                            fb_pll.refdiv      = refdiv;  
                            fb_pll.clk_sys_hz  = clk_sys_hz;  
                            fb_pll.vsel        = (uint32_t)vsel_for(clk_sys_hz);  
                            fb_pll.is_oc       = (clk_sys_hz > VFO_CLK_SYS_NOMINAL_HZ);  
                        }  
                    }  
                }  
            }  
        }  
  
#if VFO_PLL_DEBUG  
        if (best_fb_clk > 0)  
            Serial.printf("[PLLDBG] SCAN EMPTY — fallback to flash max clk=%.3f MHz\n",  
                          best_fb_clk / 1e6);  
        else  
            Serial.printf("[PLLDBG] SCAN EMPTY — fallback to nominal 133 MHz\n");  
#endif  
        return (best_fb_clk > 0) ? fb_pll : best_pll;  
    }

    // Если лучший найденный кандидат хуже номинала 133M/int≈9  
    // (clk·int ≈ 1.2e9 < гейта) — это означает, что гейт отсёк всё  
    // и сработал только первый попавшийся. Такого не будет после  
    // правки 1, но оставляем страховку: лучше fallback, чем мусор.  
    if (best_pll.clk_sys_hz * 1ULL <= 0) {   // заглушка, best_pll валиден  
        return best_pll;  
    }

#if VFO_PLL_DEBUG  
    // === МОДЕРНИЗИРОВАННЫЙ ВЫРАВНЕННЫЙ ВЫВОД ТАБЛИЦЫ TOP-10 ===
    // Печатаем строгую шапку таблицы для удобства чтения глаз
    Serial.println(F("[PLLDBG]   #  |  clk_sys    |    VCO       | R |  F  | P1| P2|    Metric   | Frac | Spur_Off  |  Spur_Lvl  | Статус"));
    Serial.println(F("[PLLDBG] -----+-------------+--------------+---+-----+---+---+-------------+------+-----------+------------+------------------"));

    for (int i = 0; i < 20; i++) {  
        if (top10[i].clk == 0) break;  

        // Вычисляем отстройку в кГц (защита от UINT64_MAX)
        unsigned long long spur_k_hz = (top10[i].spur_off == UINT64_MAX) ? 0ULL : (top10[i].spur_off / 1000ULL);

        // Формируем строго фиксированные 16-символьные блоки для флагов, чтобы исключить пляску правого края
        const char* forbidden_str = top10[i].forbidden ? "[FORB]" : "      ";
        const char* clean_str     = top10[i].clean     ? "       " : " [DIRTY]";

        // Прецизионная разметка ширины:
        // %2d     - индекс занимает ровно 2 знака (выравнивание по правому краю)
        // %7.3f   - clk_sys (например, 382.011)
        // %8.3f   - vco (например, 2292.067)
        // %1u, %3lu, %1lu, %1lu - односимвольные и трехсимвольные делители
        // %11llu  - метрика (строго 11 позиций)
        // %4u     - pio_frac (строго 4 позиции)
        // %5llu   - отстройка спура (строго 5 позиций)
        Serial.printf("[PLLDBG] [%2d] | %7.3f MHz | %8.3f MHz | %1u | %3lu | %1lu | %1lu | %11llu | %4u | %5llu kHz | %6.1f dBc | %s%s\n",
                i, 
                top10[i].clk / 1000000.0, 
                top10[i].vco / 1000000.0,  
                (unsigned)top10[i].refdiv, 
                (unsigned long)top10[i].fbdiv,  
                (unsigned long)top10[i].p1, 
                (unsigned long)top10[i].p2,  
                (unsigned long long)top10[i].metric, 
                (unsigned)top10[i].pio_frac,  
                spur_k_hz,
                (double)top10[i].spur_lvl,
                forbidden_str,  
                clean_str);  
    }  
    Serial.println(F("[PLLDBG] -----+-------------+--------------+---+-----+---+---+-------------+------+-----------+------------+------------------"));



    // Победитель: пересчёт параметров для печати  
    VfoParameters wp;  
    vfo_pll_metric(best_pll.clk_sys_hz, target_mhz, &wp);  
    uint64_t w_spur = frac_spur_min_off_hz(wp.pio_int, wp.pio_frac,  
                                         best_pll.clk_sys_hz);  
    float w_lvl = frac_spur_level_db(wp.pio_int, wp.pio_frac);  
    Serial.printf("[PLLDBG] WINNER: clk=%.3f MHz refdiv=%lu fbdiv=%lu p1=%lu p2=%lu "  
                  "metric=%llu  int=%u frac=%u step=0x%08lX  spur_off=%llu kHz "  
                  "spur_lvl=%.1f dBc%s\n",  
                best_pll.clk_sys_hz / 1e6,  
                (unsigned long)best_pll.refdiv,  
                (unsigned long)best_pll.fbdiv,  
                (unsigned long)best_pll.p1,  
                (unsigned long)best_pll.p2,  
                (unsigned long long)min_dds_metric,  
                (unsigned)wp.pio_int, (unsigned)wp.pio_frac,  
                (unsigned long)wp.dds_step,  
                (unsigned long long)(w_spur == UINT64_MAX ? 0 : w_spur / 1000ULL),  
                (double)w_lvl,  
                best_forbidden ? " [FORBIDDEN]" : "");
#endif  
    return best_pll;  
}





// блок заполнения
static void vfo_rebuild_tone_table(uint64_t base_freq_mhz, uint64_t step_mhz) {  
    for (int i = 0; i < VFO_TONES_COUNT; i++) {  
        uint64_t tone_freq_mhz = base_freq_mhz + ((uint64_t)i * step_mhz);  
        vfo_tones[i] = calculate_raw_params_mhz(current_clk_sys_hz, tone_freq_mhz);  
    }  
    // Сбросить кэш активного тона, чтобы следующий vfo_set_tone_instant применил новые значения  
    current_active_tone = VFO_TONE_NONE;  
}



// === ИНИЦИАЛИЗАЦИЯ И СТАРТ СИСТЕМЫ ===
// Полная инициализация и запуск аппаратного VFO (PLL + PIO + дизеринг).  
void vfo_hardware_init(unsigned int base_freq_hz, double step_hz) {
    // Жесткий перезапуск изолированного ядра перед изменением параметров таблиц тонов
    multicore_reset_core1(); 

    // Глушим выход ДО передёрга PLL: работающий SM во время  
    // перезахвата PLL выплюнул бы меандр на съезжающей частоте  
    // (всплеск ниже полосы при смене сетки, напр. RSID→данные).  
    pio_sm_set_enabled(lo_pio, lo_sm, false);  
    pio_sm_set_consecutive_pindirs(lo_pio, lo_sm, pin_freq_out, 1, false);

    current_active_tone = VFO_TONE_NONE; 
    xorshift_state = VFO_RAND_SEED_INIT + time_us_32(); 
    
    if (vfo_spin_lock == nullptr) { 
        int lock_id = spin_lock_claim_unused(true); 
        vfo_spin_lock = spin_lock_init(lock_id); 
    }
    
    PllConfig target_pll;

    // ========================================================================
    // АРХИТЕКТУРНЫЙ АРБИТРАЖ ЧАСТОТЫ ШИНЫ
    // Честный сквозной автотюн при каждом старте (без эффекта памяти)
    // ========================================================================

    if (clk_boosted) { 
        // Если активирован BOOST — запускаем матричный поиск ЛУЧШЕЙ частоты PLL
        // строго под НОВУЮ целевую частоту в пределах стабильного потолка pll_ceiling
        target_pll = vfo_find_optimal_pll(base_freq_hz, vfo_effective_clk_max());

    } 
    else {
        // Если буст спит — производим штатный автотюнинг в пределах номинальных 133 МГц
            target_pll = vfo_find_optimal_pll(base_freq_hz, VFO_CLK_SYS_NOMINAL_HZ);
    }

    // Подбираем безопасное рантайм-напряжение ядра процессора (VREG)
    uint32_t selected_vsel = target_pll.vsel;
    if (selected_vsel == 0 || selected_vsel < (uint32_t)VREG_VOLTAGE_1_10) {
        selected_vsel = (target_pll.clk_sys_hz > VFO_CLK_SYS_NOMINAL_HZ) 
                        ? (uint32_t)vsel_for(target_pll.clk_sys_hz) 
                        : (uint32_t)VREG_VOLTAGE_DEFAULT;
    }

    // Физически прошиваем выбранные делители в регистры PLL чипа RP2040
    // (Этот вызов обновит и физическую частоту, и current_clk_sys_hz!)
    vfo_set_clk_sys(target_pll, selected_vsel);
    // ========================================================================

    // ========================================================================
    // ИСПРАВЛЕНО: Честный вывод BOOST строго в момент его физического захвата!
    // Теперь данные fbdiv, p1, p2 берутся из РЕАЛЬНО примененной target_pll.
    // ========================================================================
    if (clk_boosted) {
#if BOOST_DEBUG 
            Serial.printf("[BOOST  ] ON   clk_sys=%7.3f MHz  refdiv=%lu  fbdiv=%3lu  p1=%lu  p2=%lu  VCO=%4lu MHz  VSEL=%4u mV  FLASH=%6.3f MHz (BAUDR=%u)  T_CPU=%5.1f C\n",    
                      (double)current_clk_sys_hz / 1000000.0,  // Выведет честные 254.007 MHz!
                      (unsigned long)target_pll.refdiv,
                      (unsigned long)target_pll.fbdiv,    
                      (unsigned long)target_pll.p1,    
                      (unsigned long)target_pll.p2,    
                      (unsigned long)(target_pll.fbdiv * (uint32_t)(vfo_calibrated_xosc_hz() / 1000000ULL)),    
                      (unsigned)vsel_to_mv(selected_vsel),    
                      (double)current_clk_sys_hz / 1000000.0 / (double)ssi_hw->baudr,    
                      (unsigned)ssi_hw->baudr,    
                      (double)0.0);
#endif
    }
    // ========================================================================


    // Конфигурация и запуск конечного автомата (State Machine) PIO
    if (!pio_program_loaded) { 
        lo_offset = pio_add_program(lo_pio, &pio_square_program); 
        pio_program_loaded = true; 
    }
    pio_sm_config c = pio_get_default_sm_config(); 
    sm_config_set_wrap(&c, lo_offset + 0, lo_offset + 1); 
    sm_config_set_set_pins(&c, pin_freq_out, 1); 
    
    pio_gpio_init(lo_pio, pin_freq_out); 
    pio_sm_set_consecutive_pindirs(lo_pio, lo_sm, pin_freq_out, 1, true); 
    
    pio_sm_init(lo_pio, lo_sm, lo_offset, &c); 
    pio_sm_set_enabled(lo_pio, lo_sm, true);

    // Расчет базовой частоты и привязка к сетке Брезенхема
    uint64_t base_target_chz = (uint64_t)base_freq_hz * 100ULL; 
    uint64_t snapped_base_chz = base_target_chz;

    vfo_base_mhz = snapped_base_chz * 10ULL; 
    vfo_step_mhz = (uint64_t)(step_hz * 1000.0);  
    
    // Синхронный потокобезопасный расчет всей FSK/IFKP таблицы тонов
    vfo_rebuild_tone_table(vfo_base_mhz, vfo_step_mhz); 
    vfo_set_tone_instant(0);
    vfo_dither_reset();         // сброс накопителей фазы MASH-дизера
// Диагностический вывод рантайм-телеметрии в Serial  
    #if VFO_PLL_DEBUG  
        VfoParameters real_base_params = vfo_tones[0];  
        Serial.printf("\n--- VFO Runtime Diagnostics ---\n");  
        Serial.printf("Target Freq: %u Hz (Grid: %.2f Hz)\n", base_freq_hz, (double)real_base_params.target_freq_chz / 100.0);  
        Serial.printf("clk_sys    : %u Hz (Физический захват PLL: refdiv=%lu, fbdiv=%lu, p1=%lu, p2=%lu)\n",  
                      current_clk_sys_hz,  
                      (unsigned long)target_pll.refdiv,  
                      (unsigned long)target_pll.fbdiv,  
                      (unsigned long)target_pll.p1,  
                      (unsigned long)target_pll.p2);  
        // Фактическое состояние регистров PLL на момент печати (refdiv — биты [5:0] CS)  
        Serial.printf("PLL CS     : 0x%08lX (refdiv=%lu)  FB=%lu  PRIM=0x%08lX\n",  
                      (unsigned long)pll_sys_hw->cs,  
                      (unsigned long)(pll_sys_hw->cs & PLL_CS_REFDIV_BITS),  
                      (unsigned long)pll_sys_hw->fbdiv_int,  
                      (unsigned long)pll_sys_hw->prim);  
        Serial.printf("PIO Regs   : INT=%u, FRAC=%u\n", real_base_params.pio_int, real_base_params.pio_frac);  
        Serial.printf("DDS Step   : 0x%08X (%u)  dist_to_k8=%u LSB\n",  
                    real_base_params.dds_step, real_base_params.dds_step,  
                    (unsigned)dds_step_min_dist_to_k8(real_base_params.dds_step));

        // === ДИАГНОСТИКА ТАБЛИЦЫ ТОНОВ: что реально выйдет из PIO ===  
        // Эффективный делитель D = int + frac/256 + dds_step/(256·2^32)  
        // f_out = clk_sys / (2·D). Печатаем цель, факт и ошибку по каждому тону.  
        Serial.printf("[TONES] n=%u  base=%llu mHz  step=%llu mHz  clk=%u Hz\n",  
                      (unsigned)VFO_TONES_COUNT,  
                      (unsigned long long)vfo_base_mhz,  
                      (unsigned long long)vfo_step_mhz,  
                      (unsigned)current_clk_sys_hz);  
        for (int i = 0; i < VFO_TONES_COUNT; i++) {  
            const VfoParameters& t = vfo_tones[i];  
            double D = (double)t.pio_int  
                     + (double)t.pio_frac / 256.0  
                     + (double)t.dds_step / (256.0 * 4294967296.0);  
            double f_act  = (double)current_clk_sys_hz / (2.0 * D);  
            double f_want = (vfo_base_mhz + (uint64_t)i * vfo_step_mhz) / 1000.0;  
            Serial.printf("[TONES] %2u: want=%11.2f  act=%11.2f  err=%+8.2f Hz  "  
                          "int=%u frac=%u step=0x%08lX\n",  
                          i, f_want, f_act, f_act - f_want,  
                          (unsigned)t.pio_int, (unsigned)t.pio_frac,  
                          (unsigned long)t.dds_step);  
        }  

        Serial.printf("-------------------------------\n");  
    #endif

    // Безопасный атомарный пуск высокоскоростного регистрового dither-конвейера на Core 1
    tone_changed = true; 
    multicore_launch_core1(vfo_core1_entry); 
}





static uint16_t vsel_to_mv(uint32_t vsel) {  
    // vreg_voltage: VREG_VOLTAGE_0_80 == 5, шаг 50 мВ, максимум VREG_VOLTAGE_1_30 == 1300 мВ  
    return (uint16_t)(900 + (vsel - VREG_VOLTAGE_0_90) * 50);  
}



// ============================================================================
// ПЕРЕКЛЮЧАТЕЛЬ ДИАПАЗОННЫХ ПОЛОСОВЫХ ФИЛЬТРОВ
// ============================================================================

// Управление блоком переключаемых ДПФ перед смесителем
typedef struct {  
    uint32_t f_max_hz;   // диапазон действует до этой частоты включительно  
    uint8_t  code;       // 4-битный код на subband_pins[0..3]  
} SubbandEntry;  
  
static const SubbandEntry SUBBAND_TABLE[] = {  
    {  2000000UL, 4 },   // LPF_1_2  (I4)  
    {  4000000UL, 3 },   // LPF_2_4  (I3)  
    {  8000000UL, 2 },   // LPF_4_8  (I2)  
    { 16000000UL, 1 },   // LPF_8_16 (I1)  
    { 0xFFFFFFFF, 0 },   // LPF_16_30 (I0)  
};
#define SUBBAND_COUNT (sizeof(SUBBAND_TABLE)/sizeof(SUBBAND_TABLE[0]))  
  
uint8_t subband_current = 0xFF;   // кэш, чтобы не дёргать пины зря  
  
// Инициализация пинов ДПФ. Вызвать из setup() ПОСЛЕ read_and_parse_SET_txt()  
// (пины приходят из конфига). Пины == -1 (NC) пропускаются.  
void vfo_subband_init(void) {
    for (int k = 0; k < 4; k++) {  
        if (subband_pins[k] >= 0) {  
            pinMode(subband_pins[k], OUTPUT);  
            digitalWrite(subband_pins[k], LOW);  
        }  
    }  
    subband_current = 0xFF;  
}  
  
// Применить код ДПФ по частоте. Идемпотентно: при повторном вызове  
// с тем же диапазоном пины не перезаписываются (нет щелчков реле).  
void vfo_subband_apply(uint32_t freq_hz) {  
    uint8_t want = SUBBAND_TABLE[SUBBAND_COUNT - 1].code;  
    for (uint8_t i = 0; i < SUBBAND_COUNT; i++) {  
        if (freq_hz <= SUBBAND_TABLE[i].f_max_hz) {  
            want = SUBBAND_TABLE[i].code;  
            break;  
        }  
    }  
    if (want == subband_current) return;     // диапазон не сменился  
    subband_current = want;  
  
    for (int k = 0; k < 4; k++) {  
        if (subband_pins[k] >= 0)  
            digitalWrite(subband_pins[k], (want >> k) & 1);  
    }  
    Serial.printf("[BPF] f=%lu Hz -> ДПФ код=%u (pins %d,%d,%d,%d)\n",  
                  (unsigned long)freq_hz, want,  
                  subband_pins[0], subband_pins[1],  
                  subband_pins[2], subband_pins[3]);  
}





// ============================================================================
// ПРОГРАММЫ-ПОМОЩНИКИ
// ============================================================================

// Отсоединение периферийного домена clk_peri от системной шины.  
static void __not_in_flash_func(detach_peripheral_clock)() {  
    clock_configure(clk_peri, 0, CLOCKS_CLK_PERI_CTRL_AUXSRC_VALUE_CLKSRC_PLL_USB, 48 * 1000000, 48 * 1000000);  
}
  
// Синхронное управление ключом эфира (нажатие/отпускание CW-ключа).  
void __not_in_flash_func(vfo_operation_set)(bool key_down) {
    // 1. Управляем направлением пина генератора PIO (высокочастотный меандр)
    if (quad_active) return;  
    pio_sm_set_consecutive_pindirs(lo_pio, lo_sm, pin_freq_out, 1, key_down);
}

// одношаговый генератор псевдослучайных чисел Xorshift32.  
static inline __attribute__((always_inline)) uint32_t __not_in_flash_func(vfo_xorshift32_raw)(uint32_t state) {
    state ^= state << 13;
    state ^= state >> 17;
    state ^= state << 5;
    return state;
}

// Одношаговый генератор псевдослучайных чисел Xorshift32  
static inline __attribute__((always_inline)) uint32_t __not_in_flash_func(vfo_xorshift32)() {
    uint32_t x = xorshift_state;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    xorshift_state = x;
    return x;
}

// Помощник автоматического определения напряжения ядра под частоту шины  
static vreg_voltage vsel_for(uint64_t clk_hz) {  
    if (clk_hz >= 250000000ULL)      return VREG_VOLTAGE_1_30; // >=250 МГц — только легальный максимум  
    else if (clk_hz >= 200000000ULL) return VREG_VOLTAGE_1_25;  
    else if (clk_hz > 133000000ULL)  return VREG_VOLTAGE_1_15;  
    return VREG_VOLTAGE_DEFAULT;  
}

void vfo_set_narrowband(bool on) {  
    uint32_t save = spin_lock_blocking(vfo_spin_lock);  
    vfo_narrowband_mode = on ? 1u : 0u;  
    spin_unlock(vfo_spin_lock, save);  
}

// Мгновенная смена активного тона частотной сетки (FSK-переход).  
void __not_in_flash_func(vfo_set_tone_instant)(uint8_t tone_index) {
    if (tone_index >= VFO_TONES_COUNT) return; 
    if (tone_index == current_active_tone) return;

    uint32_t save = spin_lock_blocking(vfo_spin_lock);  
    target_pio_int   = vfo_tones[tone_index].pio_int;  
    target_pio_frac8 = vfo_tones[tone_index].pio_frac;  
    dds_step         = vfo_tones[tone_index].dds_step;  
  
    // Маску выбираем здесь же, в атомарной сессии — чтобы Core1 прочитал  
    // консистентный снимок (int/frac/step/mask) в одном захвате лока.  
    // Глубина FRAC-дизера по величине делителя: ±N единиц FRAC-байта  
    // — это относительная ФМ-глубина ~mask/(256·int). На малых int  
    // (ВЧ-диапазоны) даже ±1 поднимает ближнюю юбку — выключаем.  
    if (vfo_narrowband_mode) {  
        vfo_frac_dither_mask = 0x00u;  // дизер выключен — чистые линии
    } else if (target_pio_int >= 38) {  
        vfo_frac_dither_mask = 0x03u;  // ±3  (80 м: int 38–56)
    } else if (target_pio_int >= 19) {  
        vfo_frac_dither_mask = 0x01u;  // ±1  (40/30 м: int 19–37)
    } else {  
        vfo_frac_dither_mask = 0x00u;  // off (20 м и выше: int ≤18)
    }

    // Накопители НЕ сбрасываем: переход mark/space фазово-непрерывный,  
    // спектрального всплеска на битовых границах RTTY больше нет.  
    tone_changed    = true;        // ← поднимаем флаг последним    
    spin_unlock(vfo_spin_lock, save); 

#if VFO_PLL_DEBUG 
    // в конце vfo_set_tone_instant, после spin_unlock — только под VFO_PLL_DEBUG:  
    uint32_t d = lo_pio->sm[lo_sm].clkdiv;  
    Serial.printf("[TONE] idx=%u applied: int=%lu frac=%lu step=0x%08lX | table: int=%u frac=%u step=0x%08lX\n",  
        tone_index,  
        (unsigned long)(d >> 16), (unsigned long)((d >> 8) & 0xFF),  
        (unsigned long)dds_step,  
        (unsigned)vfo_tones[tone_index].pio_int, (unsigned)vfo_tones[tone_index].pio_frac,  
        (unsigned long)vfo_tones[tone_index].dds_step);
#endif
    current_active_tone = tone_index;
}
 
// сброс состояния MASH-дизера и накопителей фазы.  
void __not_in_flash_func(vfo_dither_reset)(void) {  
    uint32_t save = spin_lock_blocking(vfo_spin_lock);  
    dds_accum_m2    = 0;  
    m2_carry_prev   = 0;  
    dds_accumulator = 0;  
    dither_reset_pending = true;   // новый volatile-флаг  
    spin_unlock(vfo_spin_lock, save);  
}




// ============================================================================
// РАЗГОННЫЙ БЛОК - ПОИСК ЧАСТОТНЫХ ЛИМИТОВ ПРОЦЕССОРА
// ============================================================================
 
void __not_in_flash_func(vfo_find_max_stable_clock)(void) {  
    const uint64_t CLK_START_HZ = VFO_CLK_SYS_NOMINAL_HZ;  
    const uint64_t CLK_CEIL_HZ  = 450000000ULL; // Верхний теоретический предел сканирования
  
    // Scratch-регистр watchdog для сохранения частоты при зависании
    volatile uint32_t *scratch = &watchdog_hw->scratch[0];  
  
    struct VselStep { uint64_t max_hz; vreg_voltage vsel; };  
    const VselStep vsel_table[] = {  
        { 150000000ULL, VREG_VOLTAGE_1_15 },  
        { 200000000ULL, VREG_VOLTAGE_1_20 },  
        { 250000000ULL, VREG_VOLTAGE_1_25 },  
        { 450000000ULL, VREG_VOLTAGE_1_30 }, 
    };  
    const size_t vsel_table_size = sizeof(vsel_table) / sizeof(vsel_table[0]);  
  
    struct Candidate { uint32_t fbdiv, p1, p2, refdiv; uint64_t clk_sys_hz; };  
    // Дедупликация схлопывает конфиги с одинаковым clk_sys — реальных  
    // уникальных ступеней заметно меньше тысячи, 512 хватает с запасом.  
    static Candidate cand[512];    
    const int CAND_CAP = (int)(sizeof(cand) / sizeof(cand[0]));  
    bool cand_overflow = false;
    int cand_count = 0;  
  
    // 1. СБОР КАНДИДАТОВ
    uint32_t refdiv = 1; {
        uint64_t f_ref = vfo_calibrated_xosc_hz() / refdiv;
        
        for (uint32_t fbdiv = 30; fbdiv <= 320; fbdiv++) {  
            uint64_t vco_hz = (uint64_t)fbdiv * f_ref;  
            
            // Граница аналогового захвата VCO
            // Нижний предел VCO — даташит 750 МГц  
            if (vco_hz < 750000000ULL) continue;  
            // Верхний предел — доказанный PLLTEST потолок из flash (паспорт 1600М),  
            // зажатый аппаратным барьером PLL_MAX_HZ  
            if (vco_hz > vfo_effective_pll_max()) continue;
  
            for (uint32_t p1 = 2; p1 <= 7; p1++) {  
                for (uint32_t p2 = 1; p2 <= 7; p2++) {  
                    if (p1 < p2) continue; // Соблюдаем ВЧ-правило p1 >= p2
                    
                    uint64_t cs = vco_hz / ((uint64_t)p1 * p2);  
                    if (cs <= CLK_START_HZ || cs > CLK_CEIL_HZ) continue;  
                    
                    if (cand_count >= CAND_CAP) { cand_overflow = true; goto cand_done; }  
                    cand[cand_count++] = { fbdiv, p1, p2, refdiv, cs }; 
                }  
            }  
        }  
    }  
  cand_done:

    // 2. СОРТИРОВКА: Строго снизу вверх по частоте clk_sys_hz (от 133 МГц до 450 МГц)
    for (int a = 0; a < cand_count - 1; a++) {  
        for (int b = a + 1; b < cand_count; b++) {  
            if (cand[b].clk_sys_hz < cand[a].clk_sys_hz) {  
                Candidate t = cand[a]; cand[a] = cand[b]; cand[b] = t;  
            }  
        }  
    }  

    // после сортировки равные clk_sys_hz стоят рядом,  
    // так что один проход корректно схлопывает дубли. При равной частоте  
    // оставляем вариант с большим fbdiv/refdiv (выше VCO = стабильнее петля).  
        int w_pos = 0;    
        for (int r = 0; r < cand_count; r++) {    
            if (w_pos > 0 && cand[r].clk_sys_hz == cand[w_pos - 1].clk_sys_hz) {  
                uint64_t vco_current = (uint64_t)cand[r].fbdiv / cand[r].refdiv;  
                uint64_t vco_saved   = (uint64_t)cand[w_pos - 1].fbdiv / cand[w_pos - 1].refdiv;  
                if (vco_current > vco_saved) {  
                    cand[w_pos - 1] = cand[r];  
                }  
            } else {  
                cand[w_pos++] = cand[r];    
            }    
        }    
        cand_count = w_pos;
  
    bool max_ok = false;  
    static uint32_t stress_buf[1024]; // 4 КБ SRAM для CRC-теста шины AHB
  

    Serial.printf("[OCTEST] Начинаем прецизионный прогон (R=1..3). Ступеней на сканирование: %d%s\n",  
                  cand_count, cand_overflow ? " [OVERFLOW — увеличьте cand[]]" : "");
    delay(200); // Даем очиститься буферу UART

    // --- ДЕЦИМАЦИЯ СЕТКИ: не более ~80 ступеней ---  
    // Проходим отсортированный список с шагом stride, всегда включаем  
    // самый высокий кандидат, чтобы потолок измерялся до края.  
    {  
        const int MAX_STEPS = 80;  
        if (cand_count > MAX_STEPS) {  
            int stride = (cand_count + MAX_STEPS - 1) / MAX_STEPS; // ceil  
            int w = 0;  
            for (int i = 0; i < cand_count; i += stride) {  
                cand[w++] = cand[i];  
            }  
            // Последний (максимальный) кандидат — обязательно в списке  
            if (cand[w - 1].clk_sys_hz != cand[cand_count - 1].clk_sys_hz) {  
                cand[w++] = cand[cand_count - 1];  
            }  
            cand_count = w;  
        }  
    }

    // 4. ГОРЯЧИЙ ЦИКЛ СТРЕСС-ТЕСТА
    for (int i = 0; i < cand_count; i++) {  
  
        vreg_voltage vsel = VREG_VOLTAGE_1_30;  
        for (size_t k = 0; k < vsel_table_size; k++) {  
            if (cand[i].clk_sys_hz <= vsel_table[k].max_hz) {  
                vsel = vsel_table[k].vsel;  
                break;  
            }  
        }  
  
        PllConfig step_cfg = {  
            cand[i].fbdiv, cand[i].p1, cand[i].p2,  
            cand[i].clk_sys_hz, (uint32_t)vsel, true, cand[i].refdiv 
        };  
  
        // Пишем МГц в регистр. Если плата зависнет, после ребута вы прочтете это число
        *scratch = (uint32_t)(cand[i].clk_sys_hz / 1000000ULL);  
  
        // Переключаем частоту и питание
        vfo_set_clk_sys(step_cfg, (uint32_t)vsel);  
  
        // --- КОМПОЗИТНЫЙ ВЕРИФИКАЦИОННЫЙ ТЕСТ ЯДРА ---  
        volatile uint32_t crc = 0xDEADBEEF;  
        uint32_t t0;  
  
        // Фаза 1: Арифметика + FPU
        {  
            volatile float acc_f = 1.000001f;  
            volatile uint32_t acc_i = 2654435761u;  
            t0 = millis();  
            while (millis() - t0 < 80) {  
                for (int n = 0; n < 1000; n++) {  
                    acc_f = acc_f * acc_f + 0.5f;  
                    acc_i = acc_i * 1664525u + 1013904223u;  
                }  
            }  
            crc ^= (uint32_t)acc_i;  
        }  
  
        // Фаза 2: AHB-Запись в SRAM
        t0 = millis();  
        while (millis() - t0 < 40) {  
            for (int w = 0; w < 1024; w++) {  
                stress_buf[w] = crc + (uint32_t)w;  
            }  
            crc++;  
        }  
  
        // Фаза 3: AHB-Чтение из SRAM с CRC верификацией
        {  
            bool sram_ok = true;  
            t0 = millis();  
            while (millis() - t0 < 40 && sram_ok) {  
                for (int w = 0; w < 1024; w++) {  
                    if (stress_buf[w] != crc - 1u + (uint32_t)w) {  
                        sram_ok = false;  
                        break;  
                    }  
                }  
            }  
            if (!sram_ok) {  
                Serial.printf("[OCTEST] FAIL (SRAM CRC) на clk_sys=%lu MHz\n", (unsigned long)(step_cfg.clk_sys_hz / 1000000ULL));  
                vfo_set_clk_sys(pll_nominal, VREG_VOLTAGE_DEFAULT);  
                return;  
            }  
        }  
  
        // Фаза 4: Аппаратный делитель SIO
        {  
            bool div_ok = true;  
            uint32_t num = crc | 1u;  
            t0 = millis();  
            while (millis() - t0 < 40 && div_ok) {  
                for (int n = 0; n < 2000; n++) {  
                    num = num * 1664525u + 1013904223u;   
                    uint32_t den = (num >> 16) | 1u;      
                    uint32_t q = hw_divider_u32_quotient(num, den);  
                    uint32_t r = hw_divider_u32_remainder(num, den);  
                    if (q * den + r != num || r >= den) {  
                        div_ok = false;  
                        break;  
                    }  
                    crc ^= q ^ (r << 16);  
                }  
            }  
            if (!div_ok) {  
                Serial.printf("[OCTEST] FAIL (SIO DIVIDER) на clk_sys=%6.1f MHz\n", (double)(step_cfg.clk_sys_hz / 1000000.0));  
                vfo_set_clk_sys(pll_nominal, VREG_VOLTAGE_DEFAULT);  
                return;  
            }  
        }  
  
        (void)crc;  
        watchdog_update();  
  

        // Ступень успешно пройдена: Читаем аппаратный статус защёлки фазы PLL [Скорректировано]
        bool is_locked = (pll_sys_hw->cs & PLL_CS_LOCK_BITS) != 0; // <--- СКОРРЕКТИРОВАНО

        uint32_t vco_mhz = (uint32_t)(((uint64_t)step_cfg.fbdiv * vfo_calibrated_xosc_hz()) / (1000000ULL * step_cfg.refdiv));  
  
        // Ваша исходная строка + параметр LOCK
        Serial.printf("[OCTEST] OK  clk_sys=%7.3f MHz  refdiv=%lu  fbdiv=%3lu  p1=%lu  p2=%lu  VCO=%4lu MHz  LOCK=%s  VSEL=%4u mV  FLASH=%6.3f MHz (BAUDR=%u)\n",  
                      step_cfg.clk_sys_hz / 1000000.0,  
                      (unsigned long)step_cfg.refdiv,
                      (unsigned long)step_cfg.fbdiv,  
                      (unsigned long)step_cfg.p1,  
                      (unsigned long)step_cfg.p2,  
                      (unsigned long)vco_mhz,  
                      is_locked ? "YES" : "LOST!", // <-- Интегрирован статус фазы
                      (unsigned)vsel_to_mv((uint32_t)vsel),  
                      step_cfg.clk_sys_hz / 1000000.0 / (double)ssi_hw->baudr,
                      (unsigned)ssi_hw->baudr);  // <-- Выводим также итоговый BAUDR флэша
        Serial.flush();
 
        
        pll_ceiling = step_cfg;  
        max_ok = true;

        // Перезаписываем достигнутый потолок во Flash со сдвигом -3%.  
        // Flash пишется только на номинале: откат -> сохранение -> возврат на ступень.  
        uint32_t proven_hz = (uint32_t)((step_cfg.clk_sys_hz * 97ULL) / 100ULL);  
        vfo_set_clk_sys(pll_nominal, VREG_VOLTAGE_DEFAULT);  
        //persist_clock_limits(proven_hz, 0);   // 0 = не трогаем лимит PLL  
        Serial.printf("[OCTEST] flash: clk_sys_max=%lu Hz (-3%% от достигнутых %llu)\n",  
                      (unsigned long)proven_hz, step_cfg.clk_sys_hz);  
        Serial.flush();  
        vfo_set_clk_sys(step_cfg, (uint32_t)vsel);
    } 
  
    *scratch = 0xFFFFFFFFu;  
    vfo_set_clk_sys(pll_nominal, VREG_VOLTAGE_DEFAULT);  
  
    if (max_ok) {  
        Serial.printf("[OCTEST] Потолок стабильности ядра зафиксирован: %6.1f МГц\n", (double)(pll_ceiling.clk_sys_hz / 1000000.0));  
    }  
}

void __not_in_flash_func(vfo_test_pll_extreme_shurm)(void) {
    // 1. ПЕРЕВОДИМ ПИТАНИЕ И СИСТЕМУ В ЭКСТРЕМАЛЬНЫЙ РЕЖИМ
    vreg_set_voltage(VREG_VOLTAGE_1_30);  
    busy_wait_us(2000);  
    detach_peripheral_clock();  
    busy_wait_us(2000);

    Serial.printf("\n=================== ТОТАЛЬНЫЙ ШТУРМ PLL ЗА БАРЬЕР 4 ГГЦ ===================\n");
    Serial.printf("[КВАРЦ] Опора жестко зафиксирована на монолитных 12.000 МГц XOSC\n");
    Serial.flush();
    busy_wait_us(10000);

    // Жестко фиксируем частоту опоры на значении откалиброванного кварца 12 МГц
    uint32_t rosc_hz = vfo_calibrated_xosc_hz();

    // Зажимаем postdiv делители на абсолютный максимум 7 x 7 = 49!
    // Это позволит VCO штурмовать 5 ГГц, удерживая ядро ниже 110 МГц!
    uint32_t target_p1 = 7;
    uint32_t target_p2 = 7;
    static volatile uint32_t stress_ram_block[512];

    // Шагаем по fbdiv от 100 до упора (320). 
    // При частоте кварца 12 МГц точка fbdiv=250 выдаст VCO = 3.0 ГГц.
    // Финал fbdiv=320 выдаст VCO = 3.84 ГГц.
    for (uint32_t fb = 90; fb <= 320; fb++) {
        uint64_t vco_hz = (uint64_t)fb * rosc_hz;
        uint32_t clk_sys_hz = (uint32_t)(vco_hz / (target_p1 * target_p2));

        // Если из-за разгона частота ядра вылетит за безопасные 150 МГц — 
        // аварийно завершаем, чтобы не сжечь цифровые затворы CPU
        if (clk_sys_hz > 150000000u) {
            Serial.printf("[ШТУРМ] Стоп! Частота ядра достигла критических %lu МГц. Прекращаем.\n", clk_sys_hz / 1000000ULL);
            break;
        }

        const uint32_t FLASH_SAFE_MAX_HZ = 48000000u;
        uint32_t ssi_baud = (clk_sys_hz + FLASH_SAFE_MAX_HZ - 1) / FLASH_SAFE_MAX_HZ;  
        ssi_baud = (ssi_baud + 1u) & ~1u; 
        if (ssi_baud < 2u)  ssi_baud = 2u;  
        if (ssi_baud > 34u) ssi_baud = 34u;  

        bool sram_failed = false;

        // --- КРИТИЧЕСКАЯ СЕКЦИЯ ПРЯМОГО СДВИГА PLL НА КВАРЦЕ ---
        uint32_t ints = save_and_disable_interrupts();  

        // Прошиваем fbdiv и postdiv каскады (p1=7, p2=7)
        pll_sys_hw->fbdiv_int = fb;
        pll_sys_hw->prim = (target_p1 << PLL_PRIM_POSTDIV1_LSB) | (target_p2 << PLL_PRIM_POSTDIV2_LSB);

        // Физически прошиваем делитель Flash-памяти до переключения clk_sys
        ssi_hw->ssienr = 0; 
        ssi_hw->baudr  = ssi_baud;  
        ssi_hw->ssienr = 1; 

        // Ожидаем захват СВЧ-фазы аналоговой петлей
        volatile uint32_t timeout = 30000;
        while (!(pll_sys_hw->cs & PLL_CS_LOCK_BITS) && --timeout);

        // Обновляем частоту системного ядра clk_sys
        clock_configure(clk_sys,  
                        CLOCKS_CLK_SYS_CTRL_SRC_VALUE_CLKSRC_CLK_SYS_AUX,  
                        CLOCKS_CLK_SYS_CTRL_AUXSRC_VALUE_CLKSRC_PLL_SYS,  
                        clk_sys_hz, clk_sys_hz);  

        // Верификационный тест ОЗУ
        uint32_t pattern = 0x55AA55AAL ^ fb;
        for (int w = 0; w < 512; w++) { stress_ram_block[w] = pattern + w; }
        for (int w = 0; w < 512; w++) { if (stress_ram_block[w] != (pattern + w)) { sram_failed = true; break; } }

        watchdog_update();  // сброс сторожевого таймера

        restore_interrupts(ints);
        // --- ВЫХОД ИЗ КРИТИЧЕСКОЙ СЕКЦИИ ---


        bool is_locked = (pll_sys_hw->cs & PLL_CS_LOCK_BITS) != 0;

        // Печать строки лога — штурмуем гигагерцы!
        Serial.printf("[СВЧ-ШТУРМ] FB=%3lu | VCO = %4lu MHz | Ядро = %3lu MHz | LOCK = %s | RAM = %s | T = %4.1f C | FLASH = %4.1f MHz\n", 
                      (unsigned long)fb,
                      (unsigned long)(vco_hz / 1000000ULL), 
                      (unsigned long)(clk_sys_hz / 1000000ULL),
                      is_locked ? "YES" : "LOST!",
                      sram_failed ? "FAIL" : "OK",
                      (double)0.0,
                      (double)clk_sys_hz / 1000000.0 / (double)ssi_hw->baudr);
        Serial.flush();

        // Как только аналоговая петля физически сорвется — фиксируем абсолютный рекорд планеты для RP2040!
        if (!is_locked || sram_failed) {
            Serial.printf("[СВЧ-ШТУРМ] ФИЗИЧЕСКИЙ СРЫВ АНАЛОГОВОЙ ПЕТЛИ PLL НА ОТМЕТКЕ VCO = %lu МГц!\n", (unsigned long)(vco_hz / 1000000ULL));
            break;
        }

        // === ФИКСАЦИЯ ШАГА: откат на номинал -> запись flash -> возврат на ступень ===  
        {  
            uint32_t proven_vco = (uint32_t)((vco_hz * 97ULL) / 100ULL);  
  
            // 1. Полный откат: clk_sys на номинал 133 МГц через штатный путь,  
            //    напряжение на VREG_VOLTAGE_DEFAULT. Все внешние опасные состояния сняты.  
            vfo_set_clk_sys(pll_nominal, VREG_VOLTAGE_DEFAULT);  
  
            // 2. Запись в dedicated-сектор (внутри: XOSC + baudr=2 на время erase/program,  
            //    возврат на текущий выход PLL_SYS после записи).  
            //persist_clock_limits(0, proven_vco);  
  
            Serial.printf("[ШТУРМ] flash: pll_vco_max=%lu Hz (-3%% от %llu)\n",  
                          (unsigned long)proven_vco, (unsigned long long)vco_hz);  
            Serial.flush();  
  
            // 3. Возврат на ступень штурма ОДИН раз: экстремальный вольтаж,  
            //    PLL на стабильном кварце с текущим fb, clk_sys на частоту шага, baudr под него.  
            vreg_set_voltage(VREG_VOLTAGE_1_30);  
            busy_wait_us(500);  
  
            uint32_t ints2 = save_and_disable_interrupts();  
            pll_sys_hw->fbdiv_int = fb;  
            pll_sys_hw->prim = (target_p1 << PLL_PRIM_POSTDIV1_LSB) | (target_p2 << PLL_PRIM_POSTDIV2_LSB);  
            ssi_hw->ssienr = 0; ssi_hw->baudr = ssi_baud; ssi_hw->ssienr = 1;  
            volatile uint32_t t2 = 30000;  
            while (!(pll_sys_hw->cs & PLL_CS_LOCK_BITS) && --t2);  
            clock_configure(clk_sys,  
                            CLOCKS_CLK_SYS_CTRL_SRC_VALUE_CLKSRC_CLK_SYS_AUX,  
                            CLOCKS_CLK_SYS_CTRL_AUXSRC_VALUE_CLKSRC_PLL_SYS,  
                            clk_sys_hz, clk_sys_hz);  
            restore_interrupts(ints2);  
        }
    }
    // Возврат в безопасный номинал
    vfo_set_clk_sys(pll_nominal, VREG_VOLTAGE_DEFAULT);
    Serial.println("===========================================================================");
    Serial.println("[СВЧ-ШТУРМ] Тест завершён. Опора сохранена на кварце.");
}


